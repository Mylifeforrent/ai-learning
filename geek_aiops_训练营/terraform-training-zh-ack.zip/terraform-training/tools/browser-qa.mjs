import http from "node:http";
import { createReadStream, existsSync } from "node:fs";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";

const toolDir = path.dirname(fileURLToPath(import.meta.url));
const rootDir = path.resolve(toolDir, "..");
const outputDir = path.join(rootDir, "qa-artifacts");
const distHtml = path.join(rootDir, "dist", "index.html");
const htmlPath = existsSync(distHtml) ? distHtml : path.join(rootDir, "terraform-training.html");
const tempDir = path.join(outputDir, "tmp");
await mkdir(tempDir, { recursive: true });
process.env.TMPDIR = tempDir;
const localRequire = createRequire(import.meta.url);
let playwright;
try {
  playwright = localRequire("playwright");
} catch (_) {
  const runtimeModules = process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES || "/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules";
  playwright = createRequire(path.join(runtimeModules, "package.json"))("playwright");
}
const { chromium } = playwright;

const server = http.createServer((request, response) => {
  if (request.url === "/" || request.url === "/index.html") {
    response.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
    createReadStream(htmlPath).pipe(response);
    return;
  }
  response.writeHead(404).end("not found");
});
await new Promise(resolve => server.listen(0, "127.0.0.1", resolve));
const { port } = server.address();
const url = `http://127.0.0.1:${port}/`;

const executablePath = chromium.executablePath();
const browser = await chromium.launch({
  headless: true,
  ...(existsSync(executablePath) ? { executablePath } : {}),
});
const results = { ok: true, url, assertions: [], consoleErrors: [] };
const assert = (condition, message) => {
  results.assertions.push({ ok: Boolean(condition), message });
  if (!condition) results.ok = false;
};

try {
  const context = await browser.newContext({ viewport: { width: 1440, height: 1000 }, permissions: ["clipboard-read", "clipboard-write"] });
  const page = await context.newPage();
  page.on("console", message => { if (message.type() === "error") results.consoleErrors.push(message.text()); });
  page.on("pageerror", error => results.consoleErrors.push(error.message));
  await page.goto(url, { waitUntil: "networkidle" });
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: "networkidle" });

  const chapterCount = await page.locator("section.chapter").count();
  const preCount = await page.locator("pre > code").count();
  const cardCount = await page.locator(".code-card").count();
  assert(chapterCount === 16, "Desktop: 16 chapters render");
  assert(preCount === cardCount && preCount >= 45, "Desktop: every code block gets a toolbar");
  assert(await page.locator("#progressText").textContent() === "0 / 16", "Progress starts at zero");

  await page.locator(".copy-button").first().click();
  await page.waitForTimeout(150);
  assert((await page.locator("#toast").textContent()).includes("复制"), "Copy action reports status");

  await page.locator("[data-complete='ch-00']").check();
  assert(await page.locator("#progressText").textContent() === "1 / 16", "Progress updates after checkbox");
  await page.reload({ waitUntil: "networkidle" });
  assert(await page.locator("[data-complete='ch-00']").isChecked(), "Progress persists after reload");
  await page.locator("[data-complete='ch-00']").uncheck();

  await page.locator("#search").fill("Terway");
  const searchVisible = await page.locator("section.chapter:not([hidden])").count();
  assert(searchVisible > 0 && searchVisible < 16, "Search narrows chapter list");
  await page.locator("#search").fill("");
  await page.locator("[data-filter='cloud']").click();
  const cloudStages = await page.locator("section.chapter:not([hidden])").evaluateAll(items => items.map(item => item.dataset.stage));
  assert(cloudStages.length > 0 && cloudStages.every(stage => stage === "cloud"), "Cloud filter shows only cloud chapters");
  await page.locator("[data-filter='all']").click();

  const oldTheme = await page.locator("html").getAttribute("data-theme");
  await page.locator(".hero .theme-toggle").click();
  const newTheme = await page.locator("html").getAttribute("data-theme");
  assert(oldTheme !== newTheme, "Theme toggle changes theme");

  await page.emulateMedia({ media: "print" });
  assert(await page.locator(".sidebar").evaluate(node => getComputedStyle(node).display === "none"), "Print style hides sidebar");
  await page.emulateMedia({ media: "screen" });
  await page.screenshot({ path: path.join(outputDir, "desktop.png"), fullPage: true });

  await page.setViewportSize({ width: 768, height: 900 });
  await page.reload({ waitUntil: "networkidle" });
  assert(await page.locator("#menuButton").isVisible(), "Tablet: mobile menu control is visible");
  await page.screenshot({ path: path.join(outputDir, "tablet.png"), fullPage: false });

  await page.setViewportSize({ width: 320, height: 780 });
  await page.reload({ waitUntil: "networkidle" });
  await page.locator("#menuButton").click();
  assert(await page.locator("body").evaluate(node => node.classList.contains("menu-open")), "Mobile: drawer opens");
  await page.keyboard.press("Escape");
  assert(await page.locator("body").evaluate(node => !node.classList.contains("menu-open")), "Mobile: Escape closes drawer");
  const noBodyOverflow = await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1);
  assert(noBodyOverflow, "Mobile: no page-level horizontal overflow at 320px");
  await page.screenshot({ path: path.join(outputDir, "mobile-320.png"), fullPage: false });

  assert(results.consoleErrors.length === 0, "No browser console/page errors");
  await context.close();
} finally {
  await browser.close();
  await new Promise(resolve => server.close(resolve));
}

await writeFile(path.join(outputDir, "browser-qa.json"), JSON.stringify(results, null, 2));
console.log(JSON.stringify(results, null, 2));
process.exitCode = results.ok ? 0 : 1;
