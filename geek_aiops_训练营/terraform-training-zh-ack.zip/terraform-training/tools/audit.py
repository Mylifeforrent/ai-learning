#!/usr/bin/env python3
"""Static delivery audit for the generated Terraform training bundle."""

from __future__ import annotations

import json
import re
import subprocess
import tempfile
from collections import Counter
from pathlib import Path

from lxml import html


ROOT = Path(__file__).resolve().parents[1]
BUNDLE = ROOT / "bundle" if (ROOT / "bundle").is_dir() else ROOT
HTML_PATH = BUNDLE / "terraform-training.html"

errors: list[str] = []
warnings: list[str] = []
checks: dict[str, object] = {}


def require(condition: bool, message: str) -> None:
    if not condition:
        errors.append(message)


raw = HTML_PATH.read_text(encoding="utf-8")
parser = html.HTMLParser(encoding="utf-8")
document = html.fromstring(raw.encode("utf-8"), parser=parser)

ids = document.xpath("//*[@id]/@id")
duplicates = sorted(key for key, count in Counter(ids).items() if count > 1)
require(not duplicates, f"Duplicate HTML IDs: {duplicates}")

anchor_targets = [href[1:] for href in document.xpath("//a[starts-with(@href, '#')]/@href") if len(href) > 1]
missing_anchors = sorted(set(anchor_targets) - set(ids))
require(not missing_anchors, f"Missing anchor targets: {missing_anchors}")

chapters = document.xpath("//section[contains(concat(' ', normalize-space(@class), ' '), ' chapter ')]")
nav_items = document.xpath("//*[@id='chapterNav']//a")
code_blocks = document.xpath("//pre/code")
require(len(chapters) == 16, f"Expected 16 chapters, found {len(chapters)}")
require(len(nav_items) == 16, f"Expected 16 navigation items, found {len(nav_items)}")
require(len(code_blocks) >= 45, f"Expected at least 45 code blocks, found {len(code_blocks)}")
require(all(chapter.get("data-stage") in {"local", "engineering", "cloud", "ops"} for chapter in chapters), "Invalid/missing chapter stage")
require(all(code.get("data-lang") and code.get("data-label") for code in code_blocks), "A code block is missing language or label metadata")

asset_violations: list[str] = []
for element in document.xpath("//script[@src] | //iframe[@src] | //img[@src] | //link[@href]"):
    value = element.get("src") or element.get("href") or ""
    if value.startswith(("http://", "https://", "//")):
        asset_violations.append(f"{element.tag}: {value}")
require(not asset_violations, f"External runtime assets found: {asset_violations}")

inline_handlers = []
for element in document.iter():
    for name in element.attrib:
        if name.lower().startswith("on"):
            inline_handlers.append(f"{element.tag}[{name}]")
require(not inline_handlers, f"Inline event handlers found: {inline_handlers}")
require("{{CODE:" not in raw and "<!-- CHAPTERS -->" not in raw, "Unresolved build token found")
require("-auto-approve" in raw and "不要" in raw, "Auto-approve safety warning missing")
require("enable_public_api" in raw and "expose_publicly" in raw, "Public exposure gates missing")

required_files = [
    "DESIGN.md",
    "README.md",
    "examples/01-zero-provider/main.tf",
    "examples/02-local-file/main.tf",
    "examples/03-modules/modules/service-file/tests/basic.tftest.hcl",
    "examples/ack/01-infra/ack.tf",
    "examples/ack/02-platform/main.tf",
    "examples/ack/java/catalog-service/CatalogService.java",
    "examples/ack/java/order-service/OrderService.java",
]
missing_files = [name for name in required_files if not (BUNDLE / name).is_file()]
require(not missing_files, f"Missing required files: {missing_files}")

for forbidden in BUNDLE.rglob("*"):
    if not forbidden.is_file():
        continue
    lower = forbidden.name.lower()
    if lower.startswith("terraform.tfstate") or lower.endswith(".tfplan") or lower.startswith("kubeconfig"):
        errors.append(f"Sensitive runtime artifact included: {forbidden.relative_to(BUNDLE)}")

secret_patterns = {
    "Alibaba Cloud AccessKey-like value": re.compile(r"\bLTAI[A-Za-z0-9]{12,}\b"),
    "private key header": re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    "AWS-style key": re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
}
for path in BUNDLE.rglob("*"):
    if not path.is_file() or path.suffix.lower() in {".png", ".jpg", ".zip"}:
        continue
    text = path.read_text(encoding="utf-8", errors="ignore")
    for label, pattern in secret_patterns.items():
        if pattern.search(text):
            errors.append(f"Possible {label} in {path.relative_to(BUNDLE)}")

# Lightweight balance check for Terraform sources when the Terraform binary is unavailable.
for path in BUNDLE.rglob("*.tf"):
    text = path.read_text(encoding="utf-8")
    scrubbed = re.sub(r'"(?:\\.|[^"\\])*"', '""', text)
    scrubbed = re.sub(r"#.*", "", scrubbed)
    for opening, closing in (("{", "}"), ("[", "]"), ("(", ")")):
        require(scrubbed.count(opening) == scrubbed.count(closing), f"Unbalanced {opening}{closing} in {path.relative_to(BUNDLE)}")

dockerfiles = list(BUNDLE.rglob("Dockerfile"))
require(len(dockerfiles) == 2, f"Expected 2 Dockerfiles, found {len(dockerfiles)}")
for path in dockerfiles:
    require("FROM " in path.read_text(encoding="utf-8"), f"No FROM in {path.relative_to(BUNDLE)}")
    require(":latest" not in path.read_text(encoding="utf-8").lower(), f"latest tag in {path.relative_to(BUNDLE)}")

platform_text = (BUNDLE / "examples/ack/02-platform/main.tf").read_text(encoding="utf-8")
for token in ("run_as_non_root", "read_only_root_filesystem", "allow_privilege_escalation", "automount_service_account_token", "seccomp_profile", "resources", "readiness_probe", "liveness_probe"):
    require(token in platform_text, f"Kubernetes safety control missing: {token}")

scripts = document.xpath("//script[not(@src)]/text()")
require(len(scripts) == 1, f"Expected one inline script, found {len(scripts)}")
if scripts:
    with tempfile.NamedTemporaryFile("w", suffix=".js", encoding="utf-8") as handle:
        handle.write(scripts[0])
        handle.flush()
        node = "/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node"
        result = subprocess.run([node, "--check", handle.name], capture_output=True, text=True, check=False)
        require(result.returncode == 0, f"Inline JavaScript syntax error: {result.stderr.strip()}")

checks.update({
    "html_bytes": len(raw.encode("utf-8")),
    "chapters": len(chapters),
    "navigation_items": len(nav_items),
    "code_blocks": len(code_blocks),
    "inline_svg_figures": len(document.xpath("//figure[svg]")),
    "bundle_files_before_report": sum(1 for path in BUNDLE.rglob("*") if path.is_file()),
    "html_parser_messages": len(parser.error_log),
    "external_runtime_assets": len(asset_violations),
    "duplicate_ids": len(duplicates),
    "missing_anchors": len(missing_anchors),
})

print(json.dumps({"ok": not errors, "checks": checks, "warnings": warnings, "errors": errors}, ensure_ascii=False, indent=2))
raise SystemExit(1 if errors else 0)
