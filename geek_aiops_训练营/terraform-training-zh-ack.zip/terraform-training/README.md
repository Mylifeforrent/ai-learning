# Terraform 实战训练营

面向软件开发工程师的中文渐进式教程：从本地零成本练习，到使用 Terraform 创建阿里云 ACK，再部署两个 Java 微服务。

## 最快开始

直接用浏览器打开：

```text
terraform-training.html
```

若浏览器对本地文件的剪贴板能力有限，可在本目录启动本地静态服务器：

```bash
python3 -m http.server 8000
```

然后访问 `http://127.0.0.1:8000/terraform-training.html`。页面本身不加载任何外部脚本、样式或图片；外部链接只在你主动点击官方参考资料时打开。

## 内容

- `terraform-training.html`：最终离线 HTML 教程，含目录、搜索、阶段筛选、学习进度、深浅主题和一键复制。
- `DESIGN.md`：课程、架构、界面、安全与 QA 设计。
- `QA_REPORT.md`：交付前检查和未验证边界。
- `examples/01-zero-provider`：无需 Provider 的 Terraform 生命周期练习。
- `examples/02-local-file`：变量、集合、模板和漂移练习。
- `examples/03-modules`：模块、mock test 与重构练习。
- `examples/ack/01-infra`：阿里云 VPC、Terway vSwitch、ACK Pro 和节点池。
- `examples/ack/02-platform`：Kubernetes Namespace、Deployment、Service。
- `examples/ack/java`：两个 Java 21 微服务与 Dockerfile。
- `tools/audit.py`、`tools/browser-qa.mjs`：可重复的静态与浏览器 QA 脚本。
- `checksums.sha256`：课程包中文件的 SHA-256 校验值。

## 建议学习顺序

按 HTML 的 00～15 章顺序完成。前 00～07 章完全在本机运行；08～15 章会访问真实阿里云账号，并在 apply 后产生费用。建议把创建、应用实验和销毁安排在同一天。

## 版本基线

- Terraform CLI `1.16.x`
- Alibaba Cloud Provider `1.293.0`
- Kubernetes Provider `3.2.x`
- Java `21`

基线日期为 2026-09-19。执行云上章节前必须重新核对官方 schema、地域能力、配额、库存和价格。

## 重要安全提示

- 不要把 AccessKey、registry 密码、`terraform.tfstate`、`*.tfplan` 或 `kubeconfig` 提交到 Git。
- 不要对真实云变更使用 `-auto-approve`。
- 公网 API 与公网业务入口默认关闭；不要为了快速验证而跳过来源限制。
- 先销毁 `02-platform`，等待负载均衡释放，再关闭删除保护并销毁 `01-infra`。
- 本包没有执行你的阿里云环境；真实 apply 前你必须审阅保存的 plan。
