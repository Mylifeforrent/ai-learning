module "service_files" {
  source   = "./modules/service-file"
  for_each = var.services

  service = merge(each.value, {
    name = each.key
  })

  output_dir = "${path.module}/generated"
}
