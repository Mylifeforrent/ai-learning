output "files" {
  description = "模块实例输出的文件路径。"
  value = {
    for name, service_module in module.service_files :
    name => service_module.filename
  }
}
