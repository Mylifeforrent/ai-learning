output "filename" {
  description = "生成文件路径。"
  value       = local_file.this.filename
}

output "content_sha256" {
  description = "生成内容的 SHA-256。"
  value       = local_file.this.content_sha256
}
