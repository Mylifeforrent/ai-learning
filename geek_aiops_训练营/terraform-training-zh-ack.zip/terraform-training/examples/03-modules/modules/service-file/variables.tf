variable "service" {
  description = "一个服务的稳定接口。"
  type = object({
    name     = string
    port     = number
    replicas = optional(number, 1)
  })

  validation {
    condition     = var.service.port >= 1 && var.service.port <= 65535
    error_message = "service.port 必须在 1 到 65535 之间。"
  }
}

variable "output_dir" {
  description = "生成文件所在目录。"
  type        = string
}
