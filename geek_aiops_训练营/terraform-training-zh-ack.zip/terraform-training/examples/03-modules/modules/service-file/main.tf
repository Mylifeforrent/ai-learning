locals {
  descriptor = merge(var.service, {
    managed_by = "terraform"
  })
}

resource "local_file" "this" {
  filename        = "${var.output_dir}/${var.service.name}.json"
  file_permission = "0644"
  content         = jsonencode(local.descriptor)
}
