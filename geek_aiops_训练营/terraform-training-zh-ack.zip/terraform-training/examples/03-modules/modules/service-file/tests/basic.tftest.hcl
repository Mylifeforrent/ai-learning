mock_provider "local" {}

run "valid_descriptor" {
  command = plan

  variables {
    service = {
      name     = "orders"
      port     = 8080
      replicas = 2
    }

    output_dir = "."
  }

  assert {
    condition     = jsondecode(local_file.this.content).name == "orders"
    error_message = "描述文件中的服务名不正确。"
  }

  assert {
    condition     = jsondecode(local_file.this.content).port == 8080
    error_message = "描述文件中的端口不正确。"
  }
}

run "reject_invalid_port" {
  command = plan

  variables {
    service = {
      name = "broken"
      port = 70000
    }

    output_dir = "."
  }

  expect_failures = [
    var.service,
  ]
}
