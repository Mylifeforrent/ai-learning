variable "services" {
  description = "以稳定业务键为地址的服务配置。"
  type = map(object({
    port     = number
    replicas = optional(number, 1)
  }))

  default = {
    catalog = {
      port = 8080
    }
    order = {
      port     = 8081
      replicas = 2
    }
  }
}
