output "service_files" {
  description = "服务名到生成文件绝对路径的映射。"
  value = {
    for name, service_file in local_file.service :
    name => service_file.filename
  }
}

output "content_sha256" {
  description = "每个文件的内容哈希。"
  value = {
    for name, service_file in local_file.service :
    name => service_file.content_sha256
  }
}
