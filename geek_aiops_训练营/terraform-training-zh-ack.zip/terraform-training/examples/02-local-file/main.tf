locals {
  enabled_services = {
    for name, service in var.services :
    name => service
    if service.enabled
  }
}

resource "local_file" "service" {
  for_each = local.enabled_services

  filename        = "${path.module}/generated/${each.key}.json"
  file_permission = "0644"
  content = templatefile("${path.module}/templates/service.json.tftpl", {
    name        = each.key
    environment = var.environment
    port        = each.value.port
    replicas    = each.value.replicas
  })
}
