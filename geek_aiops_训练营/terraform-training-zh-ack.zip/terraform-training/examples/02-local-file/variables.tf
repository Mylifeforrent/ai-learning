variable "environment" {
  description = "配置文件所属环境。"
  type        = string
  default     = "dev"

  validation {
    condition     = contains(["dev", "test", "prod"], var.environment)
    error_message = "environment 只能是 dev、test 或 prod。"
  }
}

variable "services" {
  description = "要写入本地配置文件的服务。"
  type = map(object({
    port     = number
    replicas = optional(number, 1)
    enabled  = optional(bool, true)
  }))

  default = {
    catalog = {
      port = 8080
    }
    order = {
      port     = 8081
      replicas = 2
    }
  }

  validation {
    condition = alltrue([
      for service in values(var.services) :
      service.port >= 1 && service.port <= 65535
    ])
    error_message = "所有端口必须在 1 到 65535 之间。"
  }
}
