variable "project_name" {
  description = "用于标识本次练习的项目名。"
  type        = string
  default     = "terraform-handbook"

  validation {
    condition     = can(regex("^[a-z][a-z0-9-]{2,30}$", var.project_name))
    error_message = "project_name 必须以小写字母开头，只含小写字母、数字和连字符，长度 3～31。"
  }
}

variable "environment" {
  description = "练习环境。"
  type        = string
  default     = "dev"

  validation {
    condition     = contains(["dev", "test", "prod"], var.environment)
    error_message = "environment 只能是 dev、test 或 prod。"
  }
}

variable "release" {
  description = "修改该值可观察受控替换。"
  type        = string
  default     = "v1"
}

variable "owners" {
  description = "负责该环境的成员。"
  type        = set(string)
  default     = ["alice", "bob"]
}
