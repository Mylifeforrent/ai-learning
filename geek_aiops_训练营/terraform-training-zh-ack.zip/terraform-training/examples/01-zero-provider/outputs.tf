output "workshop_summary" {
  description = "terraform_data 保存的结构化结果。"
  value       = terraform_data.workshop.output
}

output "stable_address" {
  description = "资源地址用于把配置与 state 中的对象关联起来。"
  value       = "terraform_data.workshop"
}
