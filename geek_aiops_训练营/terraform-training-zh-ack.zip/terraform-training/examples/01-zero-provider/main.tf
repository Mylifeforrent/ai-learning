locals {
  name       = "${var.project_name}-${var.environment}"
  is_prod    = var.environment == "prod"
  owner_list = sort(tolist(var.owners))
}

resource "terraform_data" "workshop" {
  input = {
    name        = local.name
    environment = var.environment
    owners      = local.owner_list
    is_prod     = local.is_prod
    release     = var.release
  }

  triggers_replace = [var.release]

  lifecycle {
    precondition {
      condition     = !local.is_prod || length(local.owner_list) >= 2
      error_message = "prod 环境至少需要两位 owner。"
    }
  }
}
