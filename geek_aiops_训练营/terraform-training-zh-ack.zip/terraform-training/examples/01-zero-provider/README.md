# 01 · 零 Provider 生命周期练习

```bash
terraform init
terraform fmt -check
terraform validate
terraform plan -out=tfplan
terraform apply tfplan
terraform state list
terraform plan
terraform destroy
```

`terraform_data` 是 Terraform 内置资源，不需要下载外部 Provider。保存的计划和 state 都按敏感文件处理。
