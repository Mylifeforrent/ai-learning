# Java demo services

These deliberately small Java 21 services use only the JDK, so the exercise focuses on Terraform and Kubernetes rather than a framework.

Before building, log in to your Alibaba Cloud Container Registry (ACR) instance. Replace the registry and namespace below:

```bash
docker build -t registry.cn-hangzhou.aliyuncs.com/your-namespace/catalog-service:v1.0.0 catalog-service
docker build -t registry.cn-hangzhou.aliyuncs.com/your-namespace/order-service:v1.0.0 order-service
docker push registry.cn-hangzhou.aliyuncs.com/your-namespace/catalog-service:v1.0.0
docker push registry.cn-hangzhou.aliyuncs.com/your-namespace/order-service:v1.0.0
```

For a production workflow, scan the images, sign them, and replace tags in Terraform with the immutable digests returned by the registry.
