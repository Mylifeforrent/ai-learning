import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.util.concurrent.Executors;

public final class OrderService {
    private static final String CATALOG_URL = System.getenv().getOrDefault(
            "CATALOG_URL", "http://127.0.0.1:8081");
    private static final HttpClient CLIENT = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(2))
            .build();

    private OrderService() {}

    public static void main(String[] args) throws IOException {
        int port = Integer.parseInt(System.getenv().getOrDefault("PORT", "8080"));
        HttpServer server = HttpServer.create(new InetSocketAddress("0.0.0.0", port), 0);
        server.createContext("/health", exchange ->
                respond(exchange, 200, "{\"status\":\"UP\"}"));
        server.createContext("/ready", OrderService::ready);
        server.createContext("/api/orders", OrderService::order);
        server.setExecutor(Executors.newVirtualThreadPerTaskExecutor());
        server.start();
        System.out.println("order-service listening on :" + port + ", catalog=" + CATALOG_URL);
    }

    private static void ready(HttpExchange exchange) throws IOException {
        try {
            HttpResponse<String> response = get(CATALOG_URL + "/health");
            int status = response.statusCode() == 200 ? 200 : 503;
            respond(exchange, status, "{\"status\":\"" + (status == 200 ? "READY" : "NOT_READY") + "\"}");
        } catch (InterruptedException error) {
            Thread.currentThread().interrupt();
            respond(exchange, 503, "{\"status\":\"NOT_READY\"}");
        } catch (Exception error) {
            respond(exchange, 503, "{\"status\":\"NOT_READY\"}");
        }
    }

    private static void order(HttpExchange exchange) throws IOException {
        if (!"GET".equals(exchange.getRequestMethod())) {
            respond(exchange, 405, "{\"error\":\"method not allowed\"}");
            return;
        }

        String sku = queryValue(exchange.getRequestURI().getRawQuery(), "sku", "book");
        try {
            String encodedSku = URLEncoder.encode(sku, StandardCharsets.UTF_8);
            HttpResponse<String> catalog = get(CATALOG_URL + "/api/catalog/" + encodedSku);
            if (catalog.statusCode() != 200) {
                respond(exchange, 503, "{\"error\":\"catalog unavailable\"}");
                return;
            }
            String body = "{\"orderId\":\"demo-" + Instant.now().toEpochMilli()
                    + "\",\"status\":\"CREATED\",\"item\":" + catalog.body() + "}";
            respond(exchange, 200, body);
        } catch (InterruptedException error) {
            Thread.currentThread().interrupt();
            respond(exchange, 503, "{\"error\":\"request interrupted\"}");
        } catch (Exception error) {
            respond(exchange, 503, "{\"error\":\"catalog unavailable\"}");
        }
    }

    private static HttpResponse<String> get(String url) throws IOException, InterruptedException {
        HttpRequest request = HttpRequest.newBuilder(URI.create(url))
                .timeout(Duration.ofSeconds(3))
                .GET()
                .build();
        return CLIENT.send(request, HttpResponse.BodyHandlers.ofString());
    }

    private static String queryValue(String rawQuery, String key, String fallback) {
        if (rawQuery == null || rawQuery.isBlank()) {
            return fallback;
        }
        for (String pair : rawQuery.split("&")) {
            String[] parts = pair.split("=", 2);
            if (parts[0].equals(key) && parts.length == 2) {
                return java.net.URLDecoder.decode(parts[1], StandardCharsets.UTF_8);
            }
        }
        return fallback;
    }

    private static void respond(HttpExchange exchange, int status, String body) throws IOException {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        exchange.sendResponseHeaders(status, bytes.length);
        try (OutputStream output = exchange.getResponseBody()) {
            output.write(bytes);
        }
    }
}
