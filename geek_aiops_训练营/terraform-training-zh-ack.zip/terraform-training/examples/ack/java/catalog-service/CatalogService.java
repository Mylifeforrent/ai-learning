import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.concurrent.Executors;

public final class CatalogService {
    private CatalogService() {}

    public static void main(String[] args) throws IOException {
        int port = Integer.parseInt(System.getenv().getOrDefault("PORT", "8080"));
        HttpServer server = HttpServer.create(new InetSocketAddress("0.0.0.0", port), 0);
        server.createContext("/health", exchange ->
                respond(exchange, 200, "{\"status\":\"UP\"}"));
        server.createContext("/api/catalog", CatalogService::catalog);
        server.setExecutor(Executors.newVirtualThreadPerTaskExecutor());
        server.start();
        System.out.println("catalog-service listening on :" + port);
    }

    private static void catalog(HttpExchange exchange) throws IOException {
        if (!"GET".equals(exchange.getRequestMethod())) {
            respond(exchange, 405, "{\"error\":\"method not allowed\"}");
            return;
        }

        String path = exchange.getRequestURI().getPath();
        String prefix = "/api/catalog/";
        String sku = path.startsWith(prefix) && path.length() > prefix.length()
                ? URLDecoder.decode(path.substring(prefix.length()), StandardCharsets.UTF_8)
                : "book";
        String body = "{\"sku\":\"" + json(sku)
                + "\",\"name\":\"Terraform Field Guide\",\"price\":39.90"
                + ",\"observedAt\":\"" + Instant.now() + "\"}";
        respond(exchange, 200, body);
    }

    private static String json(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private static void respond(HttpExchange exchange, int status, String body) throws IOException {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        exchange.sendResponseHeaders(status, bytes.length);
        try (OutputStream output = exchange.getResponseBody()) {
            output.write(bytes);
        }
    }
}
