locals {
  order_service_address = try(coalesce(
    try(kubernetes_service_v1.order.status[0].load_balancer[0].ingress[0].ip, null),
    try(kubernetes_service_v1.order.status[0].load_balancer[0].ingress[0].hostname, null)
  ), null)
}

output "namespace" {
  value = kubernetes_namespace_v1.demo.metadata[0].name
}

output "local_test_command" {
  description = "Run this in another terminal, then open http://127.0.0.1:8080/api/orders?sku=book."
  value       = "kubectl -n ${var.namespace} port-forward service/order-service 8080:80"
}

output "public_endpoint" {
  description = "Populated only after expose_publicly=true and the cloud load balancer becomes ready."
  value = !var.expose_publicly ? "disabled; use port-forward" : (
    local.order_service_address == null ? "pending" : "http://${local.order_service_address}"
  )
}
