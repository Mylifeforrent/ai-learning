provider "kubernetes" {
  config_path = abspath(var.kubeconfig_path)
}
