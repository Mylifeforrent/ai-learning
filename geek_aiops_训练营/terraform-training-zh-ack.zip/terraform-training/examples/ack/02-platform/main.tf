locals {
  common_labels = {
    "app.kubernetes.io/part-of"    = "terraform-java-demo"
    "app.kubernetes.io/managed-by" = "terraform"
  }
}

resource "kubernetes_namespace_v1" "demo" {
  metadata {
    name = var.namespace
    labels = merge(local.common_labels, {
      # The workloads below satisfy the restricted Pod Security Standard.
      "pod-security.kubernetes.io/enforce" = "restricted"
      "pod-security.kubernetes.io/warn"    = "restricted"
    })
  }
}

resource "kubernetes_config_map_v1" "order" {
  metadata {
    name      = "order-config"
    namespace = kubernetes_namespace_v1.demo.metadata[0].name
    labels    = local.common_labels
  }

  data = {
    CATALOG_URL = "http://catalog-service:8080"
  }
}

resource "kubernetes_deployment_v1" "catalog" {
  metadata {
    name      = "catalog-service"
    namespace = kubernetes_namespace_v1.demo.metadata[0].name
    labels    = merge(local.common_labels, { app = "catalog-service" })
  }

  wait_for_rollout = true

  spec {
    replicas = var.replicas

    selector {
      match_labels = { app = "catalog-service" }
    }

    template {
      metadata {
        labels = merge(local.common_labels, { app = "catalog-service" })
      }

      spec {
        automount_service_account_token = false

        security_context {
          run_as_non_root = true
          run_as_user     = 10001
          run_as_group    = 10001
          fs_group        = 10001

          seccomp_profile {
            type = "RuntimeDefault"
          }
        }

        container {
          name              = "catalog"
          image             = var.catalog_image
          image_pull_policy = "IfNotPresent"

          port {
            name           = "http"
            container_port = 8080
          }

          startup_probe {
            http_get {
              path = "/health"
              port = 8080
            }
            failure_threshold = 30
            period_seconds    = 2
          }

          readiness_probe {
            http_get {
              path = "/health"
              port = 8080
            }
            period_seconds    = 5
          }

          liveness_probe {
            http_get {
              path = "/health"
              port = 8080
            }
            initial_delay_seconds = 10
            period_seconds        = 10
          }

          resources {
            requests = {
              cpu    = "100m"
              memory = "128Mi"
            }
            limits = {
              cpu    = "500m"
              memory = "256Mi"
            }
          }

          security_context {
            allow_privilege_escalation = false
            read_only_root_filesystem  = true
            run_as_non_root             = true

            capabilities {
              drop = ["ALL"]
            }
          }
        }
      }
    }
  }
}

resource "kubernetes_service_v1" "catalog" {
  metadata {
    name      = "catalog-service"
    namespace = kubernetes_namespace_v1.demo.metadata[0].name
    labels    = local.common_labels
  }

  spec {
    selector = { app = "catalog-service" }

    port {
      name        = "http"
      port        = 8080
      target_port = 8080
    }

    type = "ClusterIP"
  }
}

resource "kubernetes_deployment_v1" "order" {
  metadata {
    name      = "order-service"
    namespace = kubernetes_namespace_v1.demo.metadata[0].name
    labels    = merge(local.common_labels, { app = "order-service" })
  }

  wait_for_rollout = true

  spec {
    replicas = var.replicas

    selector {
      match_labels = { app = "order-service" }
    }

    template {
      metadata {
        labels = merge(local.common_labels, { app = "order-service" })
      }

      spec {
        automount_service_account_token = false

        security_context {
          run_as_non_root = true
          run_as_user     = 10001
          run_as_group    = 10001
          fs_group        = 10001

          seccomp_profile {
            type = "RuntimeDefault"
          }
        }

        container {
          name              = "order"
          image             = var.order_image
          image_pull_policy = "IfNotPresent"

          env_from {
            config_map_ref {
              name = kubernetes_config_map_v1.order.metadata[0].name
            }
          }

          port {
            name           = "http"
            container_port = 8080
          }

          startup_probe {
            http_get {
              path = "/health"
              port = 8080
            }
            failure_threshold = 30
            period_seconds    = 2
          }

          readiness_probe {
            http_get {
              path = "/ready"
              port = 8080
            }
            period_seconds    = 5
          }

          liveness_probe {
            http_get {
              path = "/health"
              port = 8080
            }
            initial_delay_seconds = 10
            period_seconds        = 10
          }

          resources {
            requests = {
              cpu    = "100m"
              memory = "128Mi"
            }
            limits = {
              cpu    = "500m"
              memory = "256Mi"
            }
          }

          security_context {
            allow_privilege_escalation = false
            read_only_root_filesystem  = true
            run_as_non_root             = true

            capabilities {
              drop = ["ALL"]
            }
          }
        }
      }
    }
  }
}

resource "kubernetes_service_v1" "order" {
  metadata {
    name      = "order-service"
    namespace = kubernetes_namespace_v1.demo.metadata[0].name
    labels    = local.common_labels
  }

  spec {
    selector = { app = "order-service" }

    port {
      name        = "http"
      port        = 80
      target_port = 8080
    }

    type = var.expose_publicly ? "LoadBalancer" : "ClusterIP"
  }
}
