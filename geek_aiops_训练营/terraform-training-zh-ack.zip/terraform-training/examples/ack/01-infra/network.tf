data "alicloud_enhanced_nat_available_zones" "this" {}

locals {
  discovered_zone_ids = [
    for zone in data.alicloud_enhanced_nat_available_zones.this.zones :
    zone.zone_id
  ]

  zone_ids = length(var.zone_ids) == 2 ? var.zone_ids : slice(
    local.discovered_zone_ids,
    0,
    min(2, length(local.discovered_zone_ids))
  )

  zones = {
    for index, zone_id in local.zone_ids : zone_id => {
      node_cidr = cidrsubnet(var.vpc_cidr, 4, index)
      pod_cidr  = cidrsubnet(var.vpc_cidr, 4, index + 8)
    }
  }

  common_tags = {
    Project     = var.project_name
    Environment = var.environment
    Owner       = var.owner
    ExpiresAt   = var.expires_at
    ManagedBy   = "Terraform"
  }
}

resource "alicloud_vpc" "this" {
  vpc_name  = "${var.project_name}-${var.environment}-vpc"
  cidr_block = var.vpc_cidr
  tags       = local.common_tags
}

resource "alicloud_vswitch" "node" {
  for_each = local.zones

  vpc_id       = alicloud_vpc.this.id
  zone_id      = each.key
  cidr_block   = each.value.node_cidr
  vswitch_name = "${var.project_name}-${each.key}-node"
  tags         = local.common_tags
}

resource "alicloud_vswitch" "pod" {
  for_each = local.zones

  vpc_id       = alicloud_vpc.this.id
  zone_id      = each.key
  cidr_block   = each.value.pod_cidr
  vswitch_name = "${var.project_name}-${each.key}-pod"
  tags         = local.common_tags
}
