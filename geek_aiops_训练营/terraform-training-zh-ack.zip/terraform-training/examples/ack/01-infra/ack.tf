data "alicloud_instance_types" "worker_candidates" {
  availability_zone    = local.zone_ids[0]
  cpu_core_count       = 4
  memory_size          = 8
  kubernetes_node_role = "Worker"
  system_disk_category = var.system_disk_category
}

locals {
  discovered_worker_instance_types = sort([
    for instance_type in data.alicloud_instance_types.worker_candidates.instance_types :
    instance_type.id
  ])

  worker_instance_types = length(var.worker_instance_types) > 0 ? var.worker_instance_types : slice(
    local.discovered_worker_instance_types,
    0,
    min(3, length(local.discovered_worker_instance_types))
  )
}

resource "alicloud_ecs_key_pair" "workers" {
  key_pair_name = "${var.project_name}-${var.environment}-workers"
  public_key    = file(pathexpand(var.ssh_public_key_path))
  tags          = local.common_tags
}

resource "alicloud_cs_managed_kubernetes" "this" {
  name         = "${var.project_name}-${var.environment}"
  version      = var.kubernetes_version
  cluster_spec = "ack.pro.small"

  vswitch_ids = [
    for zone_id in local.zone_ids :
    alicloud_vswitch.node[zone_id].id
  ]

  pod_vswitch_ids = [
    for zone_id in local.zone_ids :
    alicloud_vswitch.pod[zone_id].id
  ]

  service_cidr                   = var.service_cidr
  new_nat_gateway                = true
  slb_internet_enabled           = var.enable_public_api
  enable_rrsa                    = true
  proxy_mode                     = "ipvs"
  deletion_protection            = var.deletion_protection
  skip_set_certificate_authority = true

  addons {
    name = "terway-eniip"
  }

  addons {
    name = "csi-plugin"
  }

  addons {
    name = "csi-provisioner"
  }

  addons {
    name = "metrics-server"
  }

  delete_options {
    resource_type = "SLB"
    delete_mode   = "delete"
  }

  tags = local.common_tags

  lifecycle {
    precondition {
      condition     = length(local.zone_ids) == 2
      error_message = "目标地域至少需要两个支持增强型 NAT 的可用区；请显式设置 zone_ids。"
    }
  }

  timeouts {
    create = "90m"
    update = "60m"
    delete = "60m"
  }
}

resource "alicloud_cs_kubernetes_node_pool" "workers" {
  cluster_id     = alicloud_cs_managed_kubernetes.this.id
  node_pool_name = "java-apps"

  vswitch_ids = [
    for zone_id in local.zone_ids :
    alicloud_vswitch.node[zone_id].id
  ]

  instance_types       = local.worker_instance_types
  desired_size         = var.worker_count
  instance_charge_type = "PostPaid"

  system_disk_category = var.system_disk_category
  system_disk_size     = 40
  key_name             = alicloud_ecs_key_pair.workers.key_pair_name

  install_cloud_monitor = false

  labels {
    key   = "workload"
    value = "java-lab"
  }

  tags = local.common_tags

  lifecycle {
    precondition {
      condition     = length(local.worker_instance_types) > 0
      error_message = "未找到可用 4 vCPU / 8 GiB Worker 规格；请检查可用区、磁盘类型、配额并填写 worker_instance_types。"
    }
  }
}

data "alicloud_cs_cluster_credential" "kubectl" {
  cluster_id                 = alicloud_cs_managed_kubernetes.this.id
  temporary_duration_minutes = 180
  output_file                = "${path.module}/kubeconfig"

  depends_on = [alicloud_cs_kubernetes_node_pool.workers]
}
