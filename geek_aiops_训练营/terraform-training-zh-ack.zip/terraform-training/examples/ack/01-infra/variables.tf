variable "region" {
  description = "阿里云地域，例如 cn-hangzhou。"
  type        = string
  default     = "cn-hangzhou"
}

variable "profile" {
  description = "可选的 Alibaba Cloud CLI profile；为 null 时使用环境变量或实例角色。"
  type        = string
  default     = null
  nullable    = true
}

variable "project_name" {
  description = "资源名称前缀。"
  type        = string
  default     = "tf-ack-lab"

  validation {
    condition     = can(regex("^[a-z][a-z0-9-]{2,24}$", var.project_name))
    error_message = "project_name 必须以小写字母开头，只含小写字母、数字和连字符，长度 3～25。"
  }
}

variable "environment" {
  description = "实验环境标签。"
  type        = string
  default     = "dev"

  validation {
    condition     = contains(["dev", "test"], var.environment)
    error_message = "此教学栈只允许 dev 或 test；不要直接用于生产。"
  }
}

variable "owner" {
  description = "成本标签中的负责人，不要填敏感标识。"
  type        = string

  validation {
    condition     = length(trimspace(var.owner)) >= 2 && lower(trimspace(var.owner)) != "replace-me"
    error_message = "owner 必须替换为真实的团队/负责人标识，不能使用 replace-me。"
  }
}

variable "expires_at" {
  description = "计划销毁日期，格式 YYYY-MM-DD。"
  type        = string

  validation {
    condition = (
      can(regex("^20[0-9]{2}-(0[1-9]|1[0-2])-([0-2][0-9]|3[0-1])$", var.expires_at)) &&
      var.expires_at != "2099-12-31"
    )
    error_message = "expires_at 必须使用真实的 YYYY-MM-DD 销毁日期，不能保留示例值 2099-12-31。"
  }
}

variable "zone_ids" {
  description = "两个可用区；空列表时从支持增强型 NAT 的可用区中选前两个。Apply 前应冻结并填写。"
  type        = list(string)
  default     = []

  validation {
    condition     = length(var.zone_ids) == 0 || length(var.zone_ids) == 2
    error_message = "zone_ids 必须为空或恰好包含两个可用区。"
  }
}

variable "vpc_cidr" {
  description = "实验 VPC CIDR；不得与现有、VPN 或对等网络重叠。"
  type        = string
  default     = "10.20.0.0/16"

  validation {
    condition     = can(cidrnetmask(var.vpc_cidr))
    error_message = "vpc_cidr 必须是合法 IPv4 CIDR。"
  }
}

variable "service_cidr" {
  description = "Kubernetes Service CIDR；创建后不可原地修改。"
  type        = string
  default     = "172.21.0.0/20"

  validation {
    condition     = can(cidrnetmask(var.service_cidr))
    error_message = "service_cidr 必须是合法 IPv4 CIDR。"
  }
}

variable "kubernetes_version" {
  description = "null 表示创建时采用 ACK 当前默认支持版本。生产应显式验证并固定。"
  type        = string
  default     = null
  nullable    = true
}

variable "worker_instance_types" {
  description = "两个可用区均有库存的候选规格。空列表时临时使用查询结果；Apply 前建议显式填写。"
  type        = list(string)
  default     = []
}

variable "worker_count" {
  description = "节点池期望节点数。"
  type        = number
  default     = 2

  validation {
    condition     = var.worker_count >= 1 && var.worker_count <= 3
    error_message = "教学环境 worker_count 必须在 1 到 3 之间。"
  }
}

variable "system_disk_category" {
  description = "目标可用区支持的系统盘类型。"
  type        = string
  default     = "cloud_essd"
}

variable "ssh_public_key_path" {
  description = "已有 SSH 公钥路径；Terraform 只读取公钥，不管理私钥。"
  type        = string
  default     = "~/.ssh/id_ed25519.pub"
}

variable "enable_public_api" {
  description = "是否创建 API Server 公网 SLB。默认关闭；个人电脑实验时才显式开启。"
  type        = bool
  default     = false
}

variable "public_api_acknowledgement" {
  description = "开启公网 API 时必须填 TEMPORARY_LAB_ONLY，并立即在 ACK 控制台限制来源为本人出口 /32。"
  type        = string
  default     = ""

  validation {
    condition     = !var.enable_public_api || var.public_api_acknowledgement == "TEMPORARY_LAB_ONLY"
    error_message = "开启公网 API 前必须将 public_api_acknowledgement 设为 TEMPORARY_LAB_ONLY。"
  }
}

variable "deletion_protection" {
  description = "集群删除保护；销毁前需单独改为 false 并 apply。"
  type        = bool
  default     = true
}
