terraform {
  required_version = "~> 1.16.0"

  required_providers {
    alicloud = {
      source  = "aliyun/alicloud"
      version = "= 1.293.0"
    }
  }
}
