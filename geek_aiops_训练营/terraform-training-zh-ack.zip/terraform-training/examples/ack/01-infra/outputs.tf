output "region" {
  description = "工作负载栈使用的地域。"
  value       = var.region
}

output "cluster_id" {
  description = "ACK 集群 ID。"
  value       = alicloud_cs_managed_kubernetes.this.id
}

output "selected_zone_ids" {
  description = "本次选择的两个可用区；Apply 前应写回 tfvars 以冻结。"
  value       = local.zone_ids
}

output "worker_instance_type_candidates" {
  description = "查询到的候选规格；Apply 前建议筛选后写入 tfvars。"
  value       = local.worker_instance_types
}

output "kubeconfig_path" {
  description = "短期 kubeconfig 的本地路径；文件已被 .gitignore 排除。"
  value       = abspath("${path.module}/kubeconfig")
}

output "api_server_internet" {
  description = "公网 API endpoint；仅在显式启用时存在。"
  value       = try(alicloud_cs_managed_kubernetes.this.connections["api_server_internet"], null)
  sensitive   = true
}

output "api_server_intranet" {
  description = "私网 API endpoint。"
  value       = try(alicloud_cs_managed_kubernetes.this.connections["api_server_intranet"], null)
  sensitive   = true
}
