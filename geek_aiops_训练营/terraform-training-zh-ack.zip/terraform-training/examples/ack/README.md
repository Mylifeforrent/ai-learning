# ACK + Java 综合实验

严格按以下顺序操作，并以 `terraform-training.html` 第 08～15 章为准：

1. 在隔离账号/资源组完成身份、权限、配额、预算和 CIDR 预检。
2. 进入 `01-infra`，复制并填写 `terraform.tfvars.example`。
3. `fmt → init → validate → plan -out → show → apply saved-plan`。
4. 验收 ACK 和节点，保护短时 `kubeconfig`。
5. 在 `java` 构建并推送两个镜像到同地域 ACR，记录镜像 digest。
6. 进入 `02-platform`，填写真实镜像，保存并审阅 plan，再 apply。
7. 通过 `kubectl port-forward` 做端到端验证。
8. 实验结束先 destroy `02-platform`，等待云负载均衡释放；再关闭 ACK 删除保护并 destroy `01-infra`。
9. 在阿里云控制台和费用中心检查 ECS、磁盘、SLB/NLB、EIP、NAT、VPC、ACK、ACR 和日志/监控残留。

## State 边界

- `01-infra` 与 `02-platform` 是两个独立 root module，不能在同一目录运行。
- 生产/团队环境应为两者使用不同 OSS backend key 和最小权限身份。
- `alicloud_cs_cluster_credential` 的敏感属性会进入 infra state；state 与生成的 kubeconfig 都按秘密保护。

## 默认安全行为

- ACK API 公网 SLB：关闭。
- Java 业务公网 LoadBalancer：关闭。
- ACK 删除保护：开启。
- Pod：Restricted 安全标准、非 root、只读根文件系统、无 ServiceAccount token 自动挂载。

