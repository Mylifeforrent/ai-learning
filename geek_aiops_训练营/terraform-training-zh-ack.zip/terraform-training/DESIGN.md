# Terraform 实战训练营：设计文档

版本：1.0  
基线日期：2026-09-19  
受众：第一次系统学习 Terraform 的软件开发工程师

## 1. 设计目标

本课程要让学习者在一条连续路径中完成以下能力迁移：

1. 在不依赖云账号的情况下理解 Terraform 的声明式模型和生命周期。
2. 能读写 HCL，使用变量、类型、集合、`for_each`、模板、输出与模块。
3. 把 state 当作敏感数据库，掌握漂移、锁、远端 backend、测试和团队评审流程。
4. 能在 apply 前评估云资源、权限、网络和费用风险。
5. 使用 Alibaba Cloud Provider 创建 VPC、双可用区 Terway 网络、ACK Pro 和独立节点池。
6. 把两个 Java 微服务制作成容器镜像，再用独立 Terraform state 部署到 Kubernetes。
7. 能执行一次滚动更新、漂移收敛、故障诊断和完整销毁。

完成标准不是“成功复制命令”，而是学习者能预测 plan、解释资源身份、判断风险、验证结果，并能安全回退或销毁。

## 2. 非目标与边界

- 这不是生产 ACK Landing Zone，也不承诺满足某个组织的合规、网络或灾备标准。
- 不自动创建 RAM 长期密钥，不在 Terraform state 中保存 registry 密码。
- 不默认创建公网 API Server 或公网业务负载均衡。
- 不写死阿里云价格、库存、配额和 Kubernetes 版本；这些必须在执行当天按地域复核。
- Java 服务故意只依赖 JDK，用于验证交付链路，不是生产业务框架模板。
- 本交付环境没有用户的阿里云凭据，因此没有执行真实 `apply`；QA 明确区分静态验证、浏览器验证和需要学习者实测的云上步骤。

## 3. 教学策略

### 3.1 渐进曲线

| 阶段 | 章节 | 反馈成本 | 核心能力 | 退出条件 |
|---|---:|---:|---|---|
| 本地基础 | 00–04 | 零费用、分钟级 | 心智模型、CLI、HCL、生命周期 | 能独立完成 init→plan→apply→destroy |
| 工程化 | 05–07 | 零费用、分钟级 | state、漂移、模块、测试、backend、评审 | 能解释状态风险并设计团队工作流 |
| 云基础设施 | 08–11 | 真实费用、数十分钟 | 权限、网络、ACK、成本与验收 | 节点 Ready，系统组件健康 |
| 应用与运维 | 12–15 | 真实费用、分钟到小时 | 镜像、Deployment、Service、排障、销毁 | 应用端到端可用且资源完整清理 |

### 3.2 固定章节节奏

每章保持相同认知结构：

1. 学习结果：明确本章结束时能做什么。
2. 概念说明：只引入当前操作需要的最少知识。
3. 实际操作：代码与命令独立成块，可一键复制。
4. 预期现象：说明应该看到什么，而不只给命令。
5. 风险提示：把高风险选择放在动作发生前。
6. 完成标准或自测：要求学习者解释而不是机械打勾。

### 3.3 面向开发者的桥接

课程使用软件工程类比降低入门成本：配置≈源码、Provider≈SDK、State≈带资源 ID 的敏感数据库、Plan≈待审阅的 migration diff。但会明确指出类比边界，避免把 plan 当作绝对保证或把 state 当作普通缓存。

## 4. 课程结构

| 章 | 标题 | 实操产物 |
|---:|---|---|
| 00 | 使用指南与安全边界 | 训练路径、文件与费用边界 |
| 01 | 建立 IaC 心智模型 | 三方比较模型、plan 审阅符号 |
| 02 | 安装与环境诊断 | Terraform 1.16.x 环境 |
| 03 | 第一次本地生命周期 | `terraform_data` 完整闭环 |
| 04 | HCL、变量与集合 | 多服务 JSON 文件 |
| 05 | 状态、漂移与替换 | 手工漂移与受控收敛 |
| 06 | 模块、测试与重构 | child module、mock test、moved/import |
| 07 | 团队工作流与远端状态 | OSS + TableStore 锁设计 |
| 08 | 阿里云准备与权限 | 身份、配额、预算、网络决策 |
| 09 | ACK 架构与成本闸门 | 双区 Terway 拓扑与费用清单 |
| 10 | 用 Terraform 创建 ACK | Infra root module |
| 11 | 计划、应用与验收 | ACK 与节点验收步骤 |
| 12 | 构建 Java 微服务镜像 | Catalog/Order Java 21 镜像 |
| 13 | 部署 Kubernetes 工作负载 | Platform root module、端到端调用 |
| 14 | 变更、漂移与排障 | 滚动更新、漂移、决策表 |
| 15 | 安全销毁与毕业挑战 | 两阶段销毁、残留审计 |

预计学习时间约 31 小时。建议拆为 6～8 次学习会话；云上创建与销毁安排在同一天。

## 5. 综合实验架构决策

### 5.1 两个 Root Module / 两个 State

- `01-infra`：VPC、vSwitch、ACK 控制面、节点池与短时 kubeconfig。高权限、低频、创建慢。
- `02-platform`：Namespace、ConfigMap、Deployment、Service。较低权限、高频、可快速滚动。

这样避免 Kubernetes Provider 在同一计划中连接尚未创建的集群，也降低状态和权限的爆炸半径。销毁按 `02-platform → 关闭删除保护 → 01-infra` 执行。

### 5.2 网络

- ACK Pro 托管集群。
- 两个可用区；每区独立 Node vSwitch 和 Pod vSwitch。
- Terway `eniip`：通过 `pod_vswitch_ids` 与 `terway-eniip` addon 配置。
- VPC `/16` 切分出四个 `/20`，Service CIDR 独立且不重叠。
- `new_nat_gateway = true` 支持节点/Pod 拉取镜像，因此 NAT/EIP/流量进入费用清单。

### 5.3 访问与凭据

- API Server 公网 SLB 默认关闭；个人电脑实验需要显式布尔值、确认字符串和 `/32` 来源限制。
- 业务 Service 默认 `ClusterIP`，通过 `kubectl port-forward` 验收。
- 集群凭据由 `alicloud_cs_cluster_credential` 生成，默认 180 分钟；文件被 Git 忽略。该 data source 的敏感属性仍会记录在 infra state 中，因此文件与 state 都按秘密处理。
- Provider 从临时角色、CLI profile 或环境读取云凭据，配置中没有 AccessKey 字段。

### 5.4 工作负载安全

- Namespace 强制 Restricted Pod Security Standard。
- Pod/Container `runAsNonRoot`，固定 UID/GID 10001。
- `allowPrivilegeEscalation=false`、`readOnlyRootFilesystem=true`、drop `ALL` capabilities、`seccomp=RuntimeDefault`。
- 不自动挂载 ServiceAccount token。
- 显式 requests/limits 与 startup/readiness/liveness probes。
- 镜像变量拒绝 `latest` 与未替换占位符，建议最终使用 digest。

## 6. 版本策略

制作时核对的版本基线：

- Terraform CLI：1.16.3；配置约束 `~> 1.16.0`。
- Alibaba Cloud Provider：1.293.0；综合实验精确固定该版本。
- Kubernetes Provider：3.2.x；配置约束 `~> 3.2`。
- Java：21；示例 Dockerfile 使用具体补丁标签，生产需进一步固定 digest。

版本会变化。课程把“执行当天重新核对 provider schema、地域能力、库存、配额、镜像和价格”设计为操作步骤，而不是页脚免责声明。

## 7. 内容与界面设计

最终 HTML 是一个无外部依赖的离线单页：

- 固定左侧目录，移动端变为抽屉。
- 中文全文搜索与本地/工程化/云上/运维阶段筛选。
- 每章完成状态写入浏览器 `localStorage`。
- 所有代码块由运行时统一加工具栏和复制按钮；优先 Clipboard API，失败时回退到选区复制。
- 深浅主题、可打印样式、跳转链接、键盘焦点与 reduced-motion 支持。
- 三张内联 SVG 图说明学习路线、Terraform 三方模型和 ACK 网络；无需联网加载图片。
- JavaScript 不可用时，正文、代码、导航和图仍然可读，只失去搜索、进度和复制增强。

视觉语言采用“工程现场手册”：深海军蓝承载导航与代码，青绿色表示可执行路径，琥珀色表示费用/风险，白色信息卡保持长文可读性。

## 8. 安全与成本控制

课程中的 P0 控制：

1. 不提供或请求真实凭据；不把凭据写入代码、变量文件、计划或 state。
2. 公网 API 与公网业务入口均默认关闭。
3. 集群删除保护默认开启，销毁前单独审批关闭。
4. 所有真实写操作先保存 plan、人工审阅，再 apply；不使用 `-auto-approve`。
5. 状态、计划和 kubeconfig 一律按敏感文件处理。
6. 云资源带 Owner/ExpiresAt/ManagedBy 标签，先设预算再创建。
7. 销毁顺序强制从工作负载到基础设施，并检查异步 LB 与账单残留。

## 9. QA 策略

交付前执行四层检查：

1. 结构检查：HTML5 解析、唯一 ID、目录锚点、无未解析模板标记。
2. 离线检查：无外链脚本/样式/图片，所有示例路径存在，不包含 state、plan、kubeconfig 或疑似密钥。
3. 浏览器检查：桌面、平板、320px 手机；搜索、筛选、复制、进度、主题、菜单与打印触发。
4. 代码静态检查：Java 编译（若运行时可用）、HCL 基本解析/格式检查（若 Terraform 可用），以及敏感模式扫描。

真实 Alibaba Cloud apply、费用和账号权限只能由学习者在自己的隔离账号中验证。`QA_REPORT.md` 记录实际执行的检查与这项边界。

## 10. Agent Teams 分工与合并原则

本交付采用六个并行角色：课程架构、Terraform 基础、阿里云 ACK、学习体验、内容 QA、安全评审。最终版本按以下优先级合并：

1. 官方当前资源 schema 与安全边界优先于教程简短。
2. 可验证的操作和完成标准优先于概念堆叠。
3. 本地零成本路径必须独立成立。
4. 综合实验必须覆盖创建、应用、验收、变更、排障与销毁完整闭环。
