# QA 报告

检查日期：2026-09-19  
交付版本：1.0

## 结论

静态交付检查通过。HTML、代码示例、目录结构、离线依赖和敏感文件扫描均未发现阻断问题。

本环境没有 Terraform、JDK、Docker 或可用的浏览器内核，也没有用户的阿里云凭据。因此，本报告**不声称**已经执行 Provider 初始化、Java/Docker 构建、真实 ACK apply 或浏览器端到端点击。相关验证步骤已在下方明确列出，学习者应在自己的隔离环境完成。

## 已执行并通过

| 检查 | 结果 | 证据摘要 |
|---|---|---|
| HTML 解析 | 通过 | lxml HTML parser：0 条解析消息 |
| 章节结构 | 通过 | 16 个章节、16 个目录项 |
| 锚点与 ID | 通过 | 0 重复 ID，0 缺失内部锚点 |
| 代码呈现 | 通过 | 76 个代码块，全部有语言和标签元数据 |
| 图示 | 通过 | 3 张内联 SVG，含 title/description/caption |
| 离线运行时依赖 | 通过 | 0 个外部 script/style/image/iframe 资源 |
| JavaScript 语法 | 通过 | Node `--check` 通过 |
| 构建占位符 | 通过 | 0 个未解析 `{{CODE:...}}` 或章节标记 |
| 敏感文件 | 通过 | 包内没有 state、plan、kubeconfig、私钥 |
| 秘密模式 | 通过 | 未发现 AccessKey 风格值或私钥头 |
| Terraform 基本结构 | 通过 | 所有 `.tf` 的 `{}`、`[]`、`()` 平衡 |
| Kubernetes 安全控制 | 通过 | 非 root、只读根、禁止提权、drop ALL、seccomp、资源与 probes 均存在 |
| 镜像基础检查 | 通过 | 2 个 Dockerfile，未使用 `latest` |
| 响应式/打印规则存在性 | 通过 | 980px、720px、print、reduced-motion CSS 均存在 |

静态审计命令：

```bash
python3 -m pip install lxml
python3 tools/audit.py
```

最近一次生成结果：最终 HTML 约 147 KB，单文件、UTF-8、无外部运行时资源。

## 未在本环境执行

### 浏览器交互

准备了 Playwright 用例，覆盖桌面/768px/320px、复制、搜索、筛选、进度持久化、主题、移动目录、打印和控制台错误。本环境没有浏览器可执行文件；尝试下载 Chromium 时网络超时，因此未将该用例标记为通过。

在装有 Playwright Chromium 的环境执行：

```bash
npm install --no-save playwright
npx playwright install chromium
node tools/browser-qa.mjs
```

人工最低验收：

1. 在 Chrome/Edge/Firefox 打开 `terraform-training.html`。
2. 点击任一“复制”，粘贴并对比代码。
3. 搜索 `Terway`，再选择“云上”筛选。
4. 勾选一章、刷新页面，确认进度保留。
5. 在 320px 视口打开/关闭目录，确认页面本体没有横向滚动。
6. 切换主题并打开打印预览。

### Terraform / Provider

本环境没有 Terraform CLI，无法运行 `fmt`、`init`、`validate`、`test` 或 Provider schema 验证。配置已按 Terraform 1.16.x、Alibaba Cloud Provider 1.293.0 和 Kubernetes Provider 3.2.x 的当前官方字段设计，并完成基本结构与交叉引用审阅。

学习者最低验收：

```bash
cd examples/01-zero-provider
terraform fmt -check -recursive
terraform init
terraform validate
terraform test

cd ../02-local-file
terraform fmt -check -recursive
terraform init
terraform validate

cd ../03-modules
terraform fmt -check -recursive
terraform init
terraform validate
terraform test
```

ACK 两个 root module 必须在读取真实 plan 后才继续，不应在自动 QA 中无凭据 apply。

### Java / Docker

本环境没有 JDK 和 Docker，无法编译源码或构建镜像。源码已人工检查 Java 21 API 使用、端口、超时、响应关闭与 Dockerfile 入口。

学习者最低验收：

```bash
cd examples/ack/java/catalog-service
javac --add-modules jdk.httpserver CatalogService.java

cd ../order-service
javac --add-modules jdk.httpserver OrderService.java

cd ..
docker build -t catalog-service:qa catalog-service
docker build -t order-service:qa order-service
```

## 真实云上验收责任

在用户自己的隔离阿里云账号执行以下检查，才能把综合实验标记为完成：

- RAM 身份、服务关联角色、地域、配额、ECS 库存和费用预估。
- `01-infra` 保存 plan 的人工审阅和 ACK apply。
- 两个 Worker Ready，Terway/CSI/system Pod 健康。
- ACR 镜像 digest 可拉取、扫描结果符合组织策略。
- `02-platform` 保存 plan 的人工审阅与端到端 order→catalog 调用。
- 工作负载先销毁、云 LB 完全释放、删除保护单独关闭、infra 销毁。
- 控制台和费用中心确认 ECS、磁盘、SLB/NLB、EIP、NAT、VPC、ACK、日志/监控与 ACR 残留。
