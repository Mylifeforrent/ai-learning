# Pi.dev 培训设计文档

> 核对日期：2026-09-20

## 1. 培训定位

训练重点不是“会聊天”，而是学会把 Pi 变成适配团队开发流程的最小 coding harness。

**目标学员**：熟悉 Git、终端、Node.js/npm 的软件开发工程师。

## 2. 教学目标

- 理解 Pi 的核心边界与扩展哲学。
- 能安装、认证并安全运行 Pi。
- 能设计 AGENTS.md、Prompt Template、Skill 和 Extension。
- 能用 SDK 将 Agent 能力嵌入内部工具。
- 能辨认 project trust、工具权限与 OS/容器 sandbox 的差异。

## 3. 教学方法

采用“概念 → 最小可运行示例 → 可控扩展 → 工程化 → 综合项目”的层层递进方式。每个概念都配对应操作步骤；关键代码单独成块；HTML 版本为所有代码块提供“一键复制”按钮。教程中加入架构示意图、流程图式卡片、检查清单和常见错误说明。

## 4. 模块设计

1. 框架心智模型
2. 安装认证与首次会话
3. AGENTS.md 项目上下文
4. Prompt Templates
5. Skills
6. Extensions
7. SDK
8. 综合项目 Repo Guardian
9. 故障排查与工程化

## 5. 综合项目

Repo Guardian：识别项目技术栈，遵守团队规则，运行/建议最小检查集，对暂存变更做标准化审查并输出 reports/ 审计报告。

综合项目不是另起炉灶，而是复用前面学过的最小能力逐步拼装，要求学员能够解释每个模块为什么存在、风险边界是什么、如何替换模型/工具/存储后端。

## 6. 验收标准

- 能独立完成安装与认证/密钥配置。
- 能从零运行一个最小 Agent。
- 能增加至少一个自定义工具或扩展能力。
- 能解释上下文、记忆、工具、执行环境与权限边界。
- 能完成综合项目，并通过教程给出的 smoke test / 检查命令。
- 能说清楚什么能力属于框架本身，什么能力来自模型、外部工具或运行时。

## 7. 版本与风险边界

Pi 官方强调本地高权限执行能力。教程默认所有练习都在可回滚 Git 仓库中完成；对不可信代码必须放入真正隔离环境。

## 8. 参考资料

- [Pi 官方文档](https://pi.dev/docs/latest)
- [Pi Quickstart](https://pi.dev/docs/latest/quickstart)
- [Pi Using](https://pi.dev/docs/latest/usage)
- [Pi Extensions](https://pi.dev/docs/latest/extensions)
- [Pi Skills](https://pi.dev/docs/latest/skills)
- [Pi SDK](https://pi.dev/docs/latest/sdk)
- [Pi Security](https://pi.dev/docs/latest/security)
