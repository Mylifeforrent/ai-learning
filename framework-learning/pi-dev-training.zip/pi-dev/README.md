# Pi.dev 培训包

- `tutorial.html`：主培训文档，浏览器直接打开，代码块带一键复制。
- `DESIGN.md`：课程设计说明。
- `final_project/`：Repo Guardian 综合项目素材。

建议先阅读 tutorial.html，再把 final_project 中的文件复制到练习仓库中演练。
