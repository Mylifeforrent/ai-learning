# Project Instructions

- Run the smallest relevant checks after source changes.
- Never edit generated/ or vendor/.
- Never run production migrations or deployment commands.
- Never print secrets from .env files.
- Prefer small, reviewable patches.
- For bug fixes: reproduce first, add a regression test, then fix.
- Final summaries must include changed files, checks run, failures, and remaining risks.
