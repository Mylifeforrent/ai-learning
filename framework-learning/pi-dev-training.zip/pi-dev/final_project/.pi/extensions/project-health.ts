import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { Type } from "typebox";
import { readFile } from "node:fs/promises";
import { join } from "node:path";

export default function (pi: ExtensionAPI) {
  pi.registerTool({
    name: "project_health",
    label: "Project Health",
    description: "Inspect common project manifests and report detected stack and scripts.",
    promptSnippet: "Inspect project manifests before deciding which checks to run",
    parameters: Type.Object({}),
    async execute(_toolCallId, _params, _signal, _onUpdate, ctx) {
      const result: Record<string, unknown> = {};

      for (const file of ["package.json", "pyproject.toml", "Cargo.toml"]) {
        try {
          const text = await readFile(join(ctx.cwd, file), "utf8");
          result[file] = file === "package.json"
            ? JSON.parse(text)
            : text.slice(0, 6000);
        } catch {
          // Manifest is optional.
        }
      }

      return {
        content: [{ type: "text", text: JSON.stringify(result, null, 2) }],
        details: { manifests: Object.keys(result) },
      };
    },
  });
}
