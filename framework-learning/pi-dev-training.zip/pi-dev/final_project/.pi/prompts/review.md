---
description: Review staged changes with project rules
---
Review `git diff --cached`.

Focus on correctness, security, missing tests, backwards compatibility,
and violations of AGENTS.md.

Target area: ${1:-all staged changes}

Return:
1. Findings ordered by severity
2. File/line references
3. Suggested fixes
4. Tests to run
