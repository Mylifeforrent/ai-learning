---
name: repo-guardian
description: Use when auditing a repository before merge or release.
---

# Repo Guardian

1. Read AGENTS.md and project manifests.
2. Use `project_health` when available.
3. Inspect changed files before editing.
4. Run or recommend the smallest relevant checks first.
5. Explain failures before changing code.
6. After fixes, rerun the failing check and one broader regression check.
7. Write `reports/repo-guardian.md` with findings and remaining risks.

## Safety
- Never print secrets from `.env`.
- Never deploy.
- Ask before destructive git operations.
