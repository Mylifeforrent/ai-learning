# Deep Agents 培训包

- tutorial.html：交互式中文培训文档
- DESIGN.md：课程设计说明
- final_project/：Release Readiness Agent Team 示例
