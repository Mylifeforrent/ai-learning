# Deep Agents 培训设计文档

> 核对日期：2026-09-20

## 1. 培训定位

以长周期、多步骤 Agent 的工程化为主线，重点理解 harness、runtime、backend、context management 和 delegation 的边界。

**目标学员**：熟悉 Python、异步/工具调用基本概念的软件开发工程师。

## 2. 教学目标

- 能用 create_deep_agent 构建可运行 Agent。
- 能定义 tools、filesystem backend、permissions。
- 能使用 skills、memory 管理上下文。
- 能设计专业 subagents 并理解隔离上下文的价值。
- 能加入 planning、checkpoint 与 human-in-the-loop。
- 能形成生产环境的安全、状态与可观测性方案。

## 3. 教学方法

采用“概念 → 最小可运行示例 → 可控扩展 → 工程化 → 综合项目”的层层递进方式。每个概念都配对应操作步骤；关键代码单独成块；HTML 版本为所有代码块提供“一键复制”按钮。教程中加入架构示意图、流程图式卡片、检查清单和常见错误说明。

## 4. 模块设计

1. 心智模型
2. 安装与第一个 Agent
3. Tools
4. Backend 与虚拟文件系统
5. Skills 与 Memory
6. Subagents
7. Planning / checkpoint / HITL
8. 综合项目 Release Readiness Agent Team
9. 生产化

## 5. 综合项目

Release Readiness Agent Team：一个主编排 Agent 委派测试和安全子任务，依据项目记忆与发布 Skill 生成受权限控制的上线审计报告。

综合项目不是另起炉灶，而是复用前面学过的最小能力逐步拼装，要求学员能够解释每个模块为什么存在、风险边界是什么、如何替换模型/工具/存储后端。

## 6. 验收标准

- 能独立完成安装与认证/密钥配置。
- 能从零运行一个最小 Agent。
- 能增加至少一个自定义工具或扩展能力。
- 能解释上下文、记忆、工具、执行环境与权限边界。
- 能完成综合项目，并通过教程给出的 smoke test / 检查命令。
- 能说清楚什么能力属于框架本身，什么能力来自模型、外部工具或运行时。

## 7. 版本与风险边界

Deep Agents 迭代很快；模型标识、middleware 组合和 backend 能力需结合当前官方文档验证。教程不把 prompt 当权限边界。

## 8. 参考资料

- [Deep Agents 官方 Overview](https://docs.langchain.com/oss/python/deepagents/overview)
- [Deep Agents GitHub](https://github.com/langchain-ai/deepagents)
- [Deep Agents examples](https://github.com/langchain-ai/deepagents/tree/main/examples)
- [Deep Agents PyPI](https://pypi.org/project/deepagents/)
