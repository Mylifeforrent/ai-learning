---
name: release-readiness
description: Use before a release or production deployment.
---

# Release Readiness

1. Inspect repository structure and dependency manifests.
2. Create a todo list for the audit.
3. Delegate test/regression analysis to `test-analyst`.
4. Delegate security review to `security-reviewer`.
5. Reconcile conflicting findings.
6. Write `/reports/release-readiness.md`.
7. Include: evidence, blockers, recommended checks, rollback notes, unresolved risks.
8. Never deploy or mutate production resources.
