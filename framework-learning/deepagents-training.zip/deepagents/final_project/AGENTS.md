# Project Memory

- This repository is being audited for release readiness.
- Never deploy automatically.
- Never reveal secrets from .env files.
- Write generated audit artifacts only under /reports/.
- Findings must include evidence and remaining uncertainty.
