import os
import sys
from pathlib import Path

from deepagents import create_deep_agent
from deepagents.backends import FilesystemBackend
from langchain.agents.middleware import TodoListMiddleware
from langgraph.checkpoint.memory import MemorySaver

MODEL = os.getenv("MODEL", "openai:gpt-5.5")
ROOT = Path(__file__).parent.resolve()
(ROOT / "reports").mkdir(exist_ok=True)

subagents = [
    {
        "name": "test-analyst",
        "description": "Analyze test coverage, likely regressions, and validation commands.",
        "model": MODEL,
        "system_prompt": (
            "You are a senior test engineer. Focus on evidence, changed surfaces, "
            "missing tests, and the smallest useful validation commands. Do not edit files."
        ),
        "tools": [],
    },
    {
        "name": "security-reviewer",
        "description": "Review repository changes for security, auth, secret, and dependency risks.",
        "model": MODEL,
        "system_prompt": (
            "You are a security reviewer. Report concrete risks and uncertainty. "
            "Never request or print secret values."
        ),
        "tools": [],
    },
]

backend = FilesystemBackend(root_dir=ROOT, virtual_mode=True)

agent = create_deep_agent(
    name="release-readiness-orchestrator",
    model=MODEL,
    system_prompt=(
        "You coordinate release-readiness reviews. Use the release-readiness skill. "
        "Delegate focused tasks to specialist subagents. Never deploy."
    ),
    subagents=subagents,
    backend=backend,
    memory=["/AGENTS.md"],
    skills=["/skills/"],
    middleware=[TodoListMiddleware()],
    permissions=[
        {
            "operations": ["read", "write"],
            "paths": ["/**/.env", "/**/.env.*"],
            "mode": "deny",
        },
        {
            "operations": ["write"],
            "paths": ["/reports/**"],
            "mode": "allow",
        },
        {
            "operations": ["write"],
            "paths": ["/**"],
            "mode": "deny",
        },
    ],
    checkpointer=MemorySaver(),
)

task = " ".join(sys.argv[1:]) or "Audit this repository for release readiness."
result = agent.invoke(
    {"messages": [{"role": "user", "content": task}]},
    config={"configurable": {"thread_id": "release-readiness-training"}},
)

print(result["messages"][-1].content)
