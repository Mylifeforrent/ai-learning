use async_trait::async_trait;
use autoagents::core::agent::memory::SlidingWindowMemory;
use autoagents::core::agent::prebuilt::executor::{ReActAgent, ReActAgentOutput};
use autoagents::core::agent::task::Task;
use autoagents::core::agent::{AgentBuilder, AgentDeriveT, AgentOutputT, DirectAgent};
use autoagents::core::error::Error;
use autoagents::core::tool::{ToolCallError, ToolInputT, ToolRuntime, ToolT};
use autoagents::llm::backends::openai::OpenAI;
use autoagents::llm::builder::LLMBuilder;
use autoagents::llm::LLMProvider;
use autoagents_derive::{agent, tool, AgentHooks, AgentOutput, ToolInput};
use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::fs;
use std::sync::Arc;

#[derive(Serialize, Deserialize, ToolInput, Debug)]
pub struct ReadFileArgs {
    #[input(description = "Relative UTF-8 text file path to inspect")]
    path: String,
}

#[tool(
    name = "ReadTextFile",
    description = "Read a UTF-8 text file from the current training project",
    input = ReadFileArgs,
)]
struct ReadTextFile {}

#[async_trait]
impl ToolRuntime for ReadTextFile {
    async fn execute(&self, args: Value) -> Result<Value, ToolCallError> {
        let typed: ReadFileArgs = serde_json::from_value(args)?;
        if typed.path.contains("..") || typed.path.starts_with('/') {
            return Ok(Value::String("Path rejected by training safety rule".into()));
        }
        if typed.path.contains(".env") {
            return Ok(Value::String("Secret-like file rejected".into()));
        }
        let text = fs::read_to_string(&typed.path)
            .unwrap_or_else(|e| format!("Could not read {}: {}", typed.path, e));
        Ok(Value::String(text.chars().take(20_000).collect()))
    }
}

#[derive(Debug, Serialize, Deserialize, AgentOutput)]
pub struct ReportOutput {
    #[output(description = "Concise report text")]
    report: String,
}

impl From<ReActAgentOutput> for ReportOutput {
    fn from(output: ReActAgentOutput) -> Self {
        let response = output.response;
        if output.done && !response.trim().is_empty() {
            if let Ok(v) = serde_json::from_str::<ReportOutput>(&response) {
                return v;
            }
        }
        Self { report: response }
    }
}

#[agent(
    name = "repo_analyst",
    description = "Analyze repository structure, dependencies and release risk",
    tools = [ReadTextFile],
    output = ReportOutput,
)]
#[derive(Default, Clone, AgentHooks)]
pub struct RepoAnalyst {}

#[agent(
    name = "test_analyst",
    description = "Analyze tests, regression coverage and validation risk",
    tools = [ReadTextFile],
    output = ReportOutput,
)]
#[derive(Default, Clone, AgentHooks)]
pub struct TestAnalyst {}

#[agent(
    name = "release_writer",
    description = "Synthesize specialist findings into a release-readiness report",
    tools = [ReadTextFile],
    output = ReportOutput,
)]
#[derive(Default, Clone, AgentHooks)]
pub struct ReleaseWriter {}

async fn build_llm() -> Arc<dyn LLMProvider> {
    let api_key = std::env::var("OPENAI_API_KEY").unwrap_or_default();
    Arc::new(
        LLMBuilder::<OpenAI>::new()
            .api_key(api_key)
            .model("gpt-4o")
            .max_tokens(1200)
            .temperature(0.2)
            .build()
            .expect("Failed to build OpenAI provider"),
    )
}

#[tokio::main]
async fn main() -> Result<(), Error> {
    let llm = build_llm().await;

    let repo_handle = AgentBuilder::<_, DirectAgent>::new(ReActAgent::new(RepoAnalyst::default()))
        .llm(llm.clone())
        .memory(Box::new(SlidingWindowMemory::new(8)))
        .build()
        .await?;

    let test_handle = AgentBuilder::<_, DirectAgent>::new(ReActAgent::new(TestAnalyst::default()))
        .llm(llm.clone())
        .memory(Box::new(SlidingWindowMemory::new(8)))
        .build()
        .await?;

    let writer_handle = AgentBuilder::<_, DirectAgent>::new(ReActAgent::new(ReleaseWriter::default()))
        .llm(llm)
        .memory(Box::new(SlidingWindowMemory::new(8)))
        .build()
        .await?;

    let repo_future = repo_handle.agent.run(Task::new(
        "Inspect README.md, Cargo.toml, package.json or pyproject.toml when present. \
         Report dependency, structure and release risks. Never read .env."
    ));
    let test_future = test_handle.agent.run(Task::new(
        "Inspect the repository for tests and validation commands. \
         Report likely regression gaps and the smallest useful release checks."
    ));

    let (repo_result, test_result) = tokio::join!(repo_future, test_future);
    let repo_report = format!("{:?}", repo_result?);
    let test_report = format!("{:?}", test_result?);

    let synthesis = format!(
        "Create a final release-readiness report with sections: evidence, blockers, \
         recommended checks, rollback notes, unresolved risks.\n\nREPO ANALYST:\n{}\n\nTEST ANALYST:\n{}",
        repo_report, test_report
    );

    let final_result = writer_handle.agent.run(Task::new(synthesis)).await?;
    println!("{:#?}", final_result);

    Ok(())
}
