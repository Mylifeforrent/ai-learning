# AutoAgents (Rust) 培训包

本包对应 `liquidos-ai/AutoAgents`，不是 autoagents.dev 的 npm CLI。

- tutorial.html：主培训文档
- DESIGN.md：课程设计
- final_project/：Release Readiness Rust Agent Team
