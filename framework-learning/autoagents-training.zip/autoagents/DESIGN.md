# AutoAgents (liquidos-ai, Rust) 培训设计文档

> 核对日期：2026-09-20

## 1. 培训定位

以 Rust 类型安全和多智能体编排为主线，从单 Agent 能跑到多个 Agent 并发协作，再延伸到 runtime/environment、WASM、guardrails 与 telemetry。

**目标学员**：熟悉 Rust/Cargo、async/await，了解 LLM tool calling 基础的软件开发工程师。

## 2. 教学目标

- 能从源码构建 AutoAgents。
- 能定义类型安全 tool input 与 agent output。
- 能使用 ReActAgent、AgentBuilder、Memory 与 provider。
- 能实现并行多 Agent 编排。
- 能理解 routing/parallel/reflection 等模式。
- 能说明 WASM、guardrails、telemetry 各自解决什么问题。

## 3. 教学方法

采用“概念 → 最小可运行示例 → 可控扩展 → 工程化 → 综合项目”的层层递进方式。每个概念都配对应操作步骤；关键代码单独成块；HTML 版本为所有代码块提供“一键复制”按钮。教程中加入架构示意图、流程图式卡片、检查清单和常见错误说明。

## 4. 模块设计

1. 同名项目辨析
2. 环境与源码构建
3. 类型安全 Tool
4. AgentBuilder / Memory / Provider
5. 多 Agent 并发与 Environment
6. 设计模式
7. WASM / Guardrails / Observability
8. 综合项目
9. 生产化

## 5. 综合项目

Release Readiness Rust Agent Team：Repo Analyst 与 Test Analyst 并行分析，Release Writer 汇总，体现 AgentBuilder、ReAct、Memory、Provider 与并发编排。

综合项目不是另起炉灶，而是复用前面学过的最小能力逐步拼装，要求学员能够解释每个模块为什么存在、风险边界是什么、如何替换模型/工具/存储后端。

## 6. 验收标准

- 能独立完成安装与认证/密钥配置。
- 能从零运行一个最小 Agent。
- 能增加至少一个自定义工具或扩展能力。
- 能解释上下文、记忆、工具、执行环境与权限边界。
- 能完成综合项目，并通过教程给出的 smoke test / 检查命令。
- 能说清楚什么能力属于框架本身，什么能力来自模型、外部工具或运行时。

## 7. 版本与风险边界

AutoAgents API 变化速度较快。为了教学项目可运行，示例按官方 README 当前 DirectAgent/ReActAgent API 编写，并建议放入源码仓库以 path dependency 构建。

## 8. 参考资料

- [AutoAgents GitHub](https://github.com/liquidos-ai/AutoAgents)
- [AutoAgents 文档](https://liquidos-ai.github.io/AutoAgents/)
- [AutoAgents README](https://github.com/liquidos-ai/AutoAgents/blob/main/README.md)
