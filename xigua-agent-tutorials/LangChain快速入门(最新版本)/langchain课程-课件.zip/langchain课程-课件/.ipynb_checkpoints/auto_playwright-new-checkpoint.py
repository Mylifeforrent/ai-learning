import os
import nest_asyncio
from dotenv import load_dotenv
from langchain.agents import create_agent
from langchain_core.tools import tool
from langchain_deepseek import ChatDeepSeek
from langgraph.checkpoint.memory import InMemorySaver
from langchain_community.agent_toolkits import PlayWrightBrowserToolkit
from langchain_community.tools.playwright.utils import create_async_playwright_browser
from langchain_core.messages import AIMessage
import asyncio

# 允许嵌套事件循环
# 解决在已有事件循环中（如Jupyter）运行异步代码时的冲突问题
nest_asyncio.apply()

# -------------------------------
# 1. 加载环境变量
# -------------------------------
# 从.env文件加载环境变量到系统环境
load_dotenv()
# 获取DeepSeek API密钥，用于身份验证
DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY")

# -------------------------------
# 2. 初始化异步 Playwright 浏览器
# -------------------------------
# 创建异步Playwright浏览器实例，用于网页自动化操作
async_browser = create_async_playwright_browser()
# 基于浏览器实例创建工具包，包含各种浏览器操作工具
toolkit = PlayWrightBrowserToolkit.from_browser(async_browser=async_browser)
# 获取所有可用的浏览器工具列表
tools = toolkit.get_tools()

# -------------------------------
# 3. 初始化 DeepSeek 模型
# -------------------------------
# 创建DeepSeek聊天模型实例，设置温度为0确保确定性输出
model = ChatDeepSeek(model="deepseek-chat", temperature=0, api_key=DEEPSEEK_API_KEY)

# -------------------------------
# 4. 配置持久化记忆
# -------------------------------
# 创建内存记忆存储器，用于保存对话历史
memory = InMemorySaver()

# -------------------------------
# 5. 创建 ReAct Agent
# -------------------------------
# 创建具备推理和工具调用能力的AI代理
agent = create_agent(
    model=model,          # 设置使用的语言模型
    tools=tools,          # 设置可用的工具列表
    checkpointer=memory   # 设置记忆存储机制
)

# -------------------------------
# 6. 测试 Agent（使用异步调用）
# -------------------------------
if __name__ == "__main__":
    # 定义用户查询：要求访问网页并总结内容
    query = "访问这个网站 https://baijiahao.baidu.com/s?id=1842116033211239200&wfr=spider&for=pc 并帮我总结一下这个网站的内容"
    # 配置线程ID，用于记忆管理和会话跟踪
    config = {"configurable": {"thread_id": "weather_agent_1"}}
    
    # 异步调用Agent处理用户查询
    # asyncio.run()用于运行异步函数并等待其完成
    response = asyncio.run(agent.ainvoke(
        {"messages": [{"role": "user", "content": query}]},  # 输入消息格式
        config=config  # 传递配置参数
    ))

    # 从响应中提取最终的AI回答
    # 初始化最终答案变量
    final_answer = None
    # 反向遍历消息列表，寻找最后一个AI生成的消息
    for message in reversed(response['messages']):
        # 检查是否为AI消息类型
        if isinstance(message, AIMessage):
            # 获取消息内容作为最终答案
            final_answer = message.content
            # 找到后跳出循环
            break

    # 打印最终的处理结果
    print("最终答案：")
    print(final_answer)
