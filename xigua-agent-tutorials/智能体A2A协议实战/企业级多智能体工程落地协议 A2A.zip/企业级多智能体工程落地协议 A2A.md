# 企业级多智能体工程落地协议 A2A

## 什么是 A2A 协议？

### 1\.1 为什么会出现 A2A 协议？

![image\.png](图片和附件/image%2011.png)

谷歌开源了首个标准智能体交互协议——Agent2Agent Protocol（简称A2A）

![image\.png](图片和附件/image%209.png)

gent2Agent（A2A）协议是⼀个开放标准： 

解决Agent 与Agent之间的通信和调⽤规则 

让所有的Agent智能体都遵守这个规则 

将所有的Agent 连接起来协同⼯作。 

### 1\.2 A2A 协议解决了什么问题？

旅行APP

![image\.png](图片和附件/image%202.png)



智能体（AI Agent ）处理不同的事情 

多个智能体需要通过消息传递和调⽤完成整件事情 

智能体之间存在⼀次或者多次沟通协作 

⽣成智能体的团队有可能不同。 

智能体⽤到的技术有可能不同。

所以需要⼀个协议（A2A）解决上述问题。

### 1\.3 A2A 协议是如何解决问题的？

为“不透明”的（⿊盒）代理系统提供了⼀种标准化的互动⽅式。它定义了： 

1. 通⽤的传输和格式： JSON\-RPC 2\.0 通过 HTTP\(S\)⽤于消息的结构和传输 

⽅式。 

> 想象每个 AI 代理就像一个只会说方言的小店老板。以前他们互相听不懂，没法合作。A2A 协议规定：大家都用 JSON\-RPC 2\.0 这种标准“普通话”写消息，并且通过 HTTP/HTTPS（就是上网常用的协议）来发送。这样一来，不管谁写的代理，只要遵守这个规则，就能互相“打电话”、“发短信”，沟通无障碍。
> 
> 

2. 发现机制（代理卡）： 代理如何宣传其功能并被其他代理发现。打标签。 

> 每个代理可以发一张“名片”（叫“代理卡”），上面写着：“我会翻译”“我能查天气”“我能处理表格”……还打上标签，比如 \#翻译 \#数据分析。别的代理看到这张名片，就知道“哦，有事可以找他帮忙”。这就解决了“我不知道谁能帮我”的问题。
> 
> 

3. 任务管理⼯作流程： 协作任务如何启动、进⾏和完成。这包括⽀持可能是⻓ 

时间运⾏或需要多次交互的任务。 

> 有时候一个任务不是一句话就能搞定的，比如“帮我订机票\+酒店\+安排接送”，可能要来回问好几次、花好几天。A2A 协议规定了怎么开始任务、中间怎么传递进度、最后怎么确认完成，甚至支持“你先去做，我等你结果”这种异步协作。这样多个代理配合起来就像一支有纪律的团队，不会乱套。
> 
> 

4. ⽀持各种数据模式： 代理如何交换不仅仅是⽂本，还有⽂件、结构化数据 

    （如表单）以及可能的其他丰富媒体。 

> 以前很多系统只能传文字，但现实中我们经常需要传 Excel 表格、PDF 文件、图片等。A2A 协议允许代理之间交换多种类型的数据，比如上传一个 CSV 文件让另一个代理分析，或者返回一张生成的图表。这让合作更实用、更贴近真实工作场景。
> 
> 

5. 安全性和异步性的核⼼原则： 安全通信和处理可能需要较⻓时间或涉及⼈机 

协作流程的任务的指导⽅针。

> - 安全性：所有通信都建议走 HTTPS，防止被偷听或篡改；还可以加身份验证，确保“找对人、不被冒充”。
> 
> - 异步性：有些任务很慢（比如训练模型、人工审核），不能一直等着。协议支持“你先忙，好了通知我”，这样系统不会卡住，也能和人类协作（比如等人审批后再继续）。
> 
> 

总结一下：

A2A 协议就像给一群“黑盒子”AI代理制定了一套合作公约——统一语言、亮明技能、规范流程、丰富工具、保障安全。从此它们不再是孤岛，而是能组队打怪的“智能联盟”。

## A2A 协议是如何设计的？

### 2\.1 A2A 协议设计的关键原则

A2A 的发展受到⼏个核⼼原则的指导： 

1. 简单性： 在可能的情况下利⽤现有且⼴为⼈知的标准，如 HTTP、JSON

RPC 和 Server\-Sent Events（SSE），⽽不是重复造轮⼦。

> A2A 不搞花里胡哨的新技术，而是直接用大家早就熟悉、广泛支持的标准，比如：
> 
> - HTTP/HTTPS（就是你上网用的协议），
> 
> - JSON\-RPC（一种结构清晰、好读好写的通信格式），
> 
> - SSE（Server\-Sent Events）（一种服务器主动推送消息给客户端的方式）。
> 
> 

> 打个比方：就像超市只提供大、中、小三种购物袋——简单、够用、谁都会用。不用每个顾客都自带袋子，也不用超市发明一种新袋子。这样开发起来快，维护也省心。
> 
> 

2. 企业就绪性： 通过与标准⽹络实践保持⼀致，从⼀开始就解决关键的企业需 

求，如身份验证、授权、安全性、隐私、追踪和监控。 

> 很多新技术在实验室很好用，但一进大公司就“水土不服”。A2A 从设计之初就想着企业实际需求：
> 
> - 谁能调用这个代理？（身份验证）
> 
> - 他有没有权限做这件事？（授权）
> 
> - 数据会不会被偷看或篡改？（安全性 \& 隐私）
> 
> - 出问题了能不能查日志？（追踪 \& 监控）
> 
> 就像开一家正规餐厅，不是光会炒菜就行，还得有营业执照、消防通道、监控摄像头——A2A 把这些“合规装备”都提前配齐了。
> 
> 

3. 优先考虑异步： 通过流式传输和推送通知等机制，本地⽀持⻓时间运⾏的任 

务和代理或⽤户可能不断连接的场景。代理/智能体之间有可能是⽹络调⽤， 

内部逻辑处理时⻓不可控。 

> 现实中很多任务很慢：比如让一个代理生成报告、处理视频，或者等人审批。如果每次都“你发请求→我死等回复”，系统就会卡住。
> 
> A2A 更推崇 异步协作：你发个任务给我，我可以边做边通过“流式传输”或“推送通知”告诉你进度（比如“50%完成了”“出错了”）。你不用一直挂着，可以去做别的事。这特别适合网络不稳定、任务耗时长、或者需要人机混合协作的场景。
> 
> 

4. 模态不可知： 允许代理使⽤各种内容类型进⾏通信，实现丰富灵活的交互， 

超越纯⽂本。⽐如⽂字、图⽚、⾳频、视频等。

> 传统聊天机器人只能处理文字，但真实世界需要更多：图片、语音、表格、视频、PDF……
> 
> A2A 的设计是“模态不可知”的，意思是：它不限定你必须用哪种内容。你想传音频？行。想回一张图表？没问题。代理之间可以像人类一样，用最合适的“媒介”交流，而不是被文字绑死。
> 
> 就像两个人合作，有时候发个截图比写一百句话更清楚——A2A 支持这种灵活沟通。
> 
> 

5. 不透明执⾏： 实现协作，⽆需要求代理公开其内部逻辑、内存或专有⼯具。 

代理基于声明的能⼒和交换的上下⽂进⾏交互，保护知识产权并增强安全 

性。

> 每个 AI 代理可能用了自家的秘密算法、私有工具或敏感数据。A2A 不要求你把“内部怎么运作的”公开出来（不像开源那样必须亮代码）。
> 
> 你只需要告诉别人：“我能做翻译”“我能分析销售数据”，然后按约定格式交换信息就行。具体你怎么做的？那是你的事。这样既保护了知识产权，又避免泄露商业机密，还能防止别人钻空子攻击你的内部逻辑。
> 
> 就像你叫外卖：你只关心饭好不好吃、送没送到，不需要知道厨师用哪口锅、放了几勺盐。
> 
> 

✅ 总结一下：

A2A 的五大原则就是为了让 AI 代理之间简单、安全、高效、灵活、隐私友好地协作——

用现成工具、满足企业要求、支持长时间任务、兼容各种内容、还不暴露内部秘密。

一句话：让黑盒代理也能组队打配合，而且打得专业又安心。

### 2\.2 A2A 协议核心概念之参与者

![image\.png](图片和附件/image.png)

1. ⽤户： 发起需要代理协助的请求或⽬标的最终⽤户（⼈类或⾃动化服务）。 

2. A2A 客户端（客户端代理）： ⼀个应⽤程序、服务或另⼀个 AI 代理，代表 

⽤户请求远程代理执⾏操作或获取信息。客户端使⽤ A2A 协议发起通信。 

3. A2A 服务器（远程代理）： ⼀个 AI 代理或代理系统，提供实现 A2A 协议 

的 HTTP 端点。它接收来⾃客户端的请求，处理任务，并返回结果或状态更 

新。从客户端的⻆度来看，远程代理作为⼀个“不透明”系统运⾏，这意味着 

客户端不需要了解其内部⼯作、内存或⼯具。

✅ 一句话总结：

用户提需求 → 客户端代理去“找人” → 远程代理默默干活并返回结果，全程不用知道对方肚子里怎么想的。

就像你叫外卖：你（用户）下单，App（客户端）联系餐厅（远程代理），餐厅做好送来——你不需要知道厨房怎么炒菜。

### 2\.3 A2A 协议核心概念之基本通信要素

1. 代理卡⽚: 让其他的代理找到⾃⼰ 

    - ⼀个 JSON 元数据⽂档，通常可以在⼀个众所周知的 URL（例如， /\.well\-known/agent\.json ）上找到，描述了⼀个 A2A 服务器。

    - 它详细描述了代理的身份（名称、描述）、服务端点 URL、版本、⽀持 的 A2A 能⼒（如流式传输或推送通知）、它提供的具体技能、默认的输⼊/输出模式以及认证要求。 

    - 客户端使⽤代理卡来发现代理并了解如何安全有效地与其交互。

想象你开了一家小店，门口挂个牌子写着：

- 店名：“智能旅行助手”

- 能干啥：订机票、做行程、查天气

- 怎么联系我：网址是 `https://travel-agent.example/.well-known/agent.json`

- 需要密码吗？需要（比如用 API Key）

- 支持边做边汇报进度吗？支持！

这个“牌子”就是 代理卡片——一个标准格式的 JSON 文件，别的 AI 一看到它，就知道：“哦，这家伙能帮我干啥、怎么调用、要不要认证”，不用瞎猜。

👉 作用：让别人轻松找到你、知道怎么跟你合作。

![image\.png](图片和附件/image%208.png)

2. 任务：具体要完成的事情（⽣成旅游规划） 

    - 当客户端向代理发送消息时，代理可能会确定完成请求需要完成⼀个有状态的任务（例如，“⽣成报告”，“预订航班”，“回答问题”）。

    - 每个任务都有代理定义的唯⼀ ID，并按照定义的⽣命周期（例如， 已提交 ， 进⾏中 ， 需要输⼊ ， 已完成 ， 失败 ）进⾏进展。 

    - 任务是有状态的，可能涉及客户端和服务器之间的多个交换（消息）。

用户说：“帮我规划一个去云南5天的旅行。”

这可不是一句话就能回完的事，可能要查航班、订酒店、排日程……
于是客户端对远程代理说：“启动一个任务！”

代理就创建一个带唯一编号的任务（比如 `task-abc123`），状态从 “已提交” → “进行中” → “需要你确认预算” → “已完成”。

整个过程可能来回沟通好几次，但都围绕同一个任务。



👉 作用：把复杂事情打包成一个“项目”，有始有终、可追踪、可中断、可继续。

![image\.png](图片和附件/image%207.png)

3. 消息： 代表客户端和代理之间的单个转向或通信单元。 

    - 消息具有 role （对于客户端发送的消息为 "user" ，对于服务器发送的消息为 "agent" ），并包含⼀个或多个携带实际内容的 Part对象。 

    - Message 对象的 messageId 部分是由消息发送者设置的每个消息的唯⼀标识符。 ⽤于传达指令、上下⽂、问题、答案或状态更新，这些内容不⼀定是正式Artifacts 。

每次客户端和代理“说话”，都是一条 消息。



比如：

- 客户端发：“我想去大理，预算5000。”（角色是 `"user"`）

- 代理回：“好的，正在查机票……”（角色是 `"agent"`）

每条消息都有唯一 ID（比如 `msg-xyz789`），方便追踪。

消息里可以包含文字、文件、数据等（通过“部分”来装）。

👉 作用：对话的基本单位，像微信聊天里的一条消息。

![image\.png](图片和附件/image%204.png)

4. 部分（Part）： 在消息或 Artifacts 中的基本内容单元。

    - 每个部分具有特定的 type ，可以携带不同类型的数据：

        - TextPart : 包含纯⽂本内容。

        - FilePart ：表示⼀个⽂件，可以作为内联 base64 编码的字节传输，也可以通过 URI 引⽤。包括⽂件名和媒体类型等元数据。

        - DataPart ：携带结构化的 JSON 数据，适⽤于表单、参数或任何可机器读取的信息。

一条消息不能只塞一堆乱七八糟的东西，得分类打包。

“部分”就是这些小包裹，每种类型干不同的事：

- TextPart：纯文字，比如“你好！”

- FilePart：文件，比如一张行程图（可以是 base64 编码直接传，也可以给个下载链接）

- DataPart：结构化数据，比如 `{ "days": 5, "budget": 5000, "destinations": ["大理", "丽江"] }`

你可以一条消息里同时发文字 \+ 文件 \+ 数据，就像微信里既能打字，又能发图片和位置。



👉 作用：让不同类型的内容各归其位，机器也能准确理解。



5. ⼯件（Artifacts）： 代表远程代理在处理任务过程中⽣成的有形输出或结果。 

    - 示例包括⽣成的⽂档、图像、电⼦表格、结构化数据结果，或任何其他作为任务直接结果的独⽴信息。

    - Artifacts 由⼀个或多个 Part 对象组成，并且可以逐步流式传输。

当任务快完成时，代理会生成一些实实在在的结果，比如：

- 一份 PDF 行程单

- 一张景点地图（图片）

- 一个 Excel 预算表

- 一段 JSON 格式的推荐列表

这些成果统称为 工件（Artifacts），它们由一个或多个 “部分（Part）” 组成。



而且可以边做边传——比如先给你文字摘要，再慢慢传高清图。

👉 作用：把任务的“交付物”标准化，方便接收方使用或展示。

![image\.png](图片和附件/image%201.png)

总的来说

> 就像你找设计师做海报：
> 
> 先看他的作品集（代理卡）→ 下单一个设计任务（任务）→ 中间聊需求、改稿（消息\+部分）→ 最后他交给你 PNG 和源文件（工件）。
> 
> 这就是 A2A 的基本通信逻辑——清晰、灵活、适合复杂协作！
> 
> 

### 2\.4 A2A 协议核心概念之交互机制

> 客户端代理向服务端代理发送任务指令 
> 
> 服务端代理处理任务需要时间 
> 
> 服务端代理如何返回客户端代理结果？
> 
> 

1）请求/响应（轮询）： 

- 客户端发送请求（例如，使⽤ message/send RPC ⽅法），并从服务器接收响应。

- 执⾏的任务需要⻓时间运⾏，服务器代理以 working 状态进⾏响应。 

- 客户端代理会定期调⽤ tasks/get 来轮询更新，直到任务达到终端状态（例如， completed ， failed ）。

### 1️⃣ 请求/响应（轮询）——像不断问“好了没？”

- 你发个请求：“开始做攻略！”

- 对方回你一句：“收到，正在处理中（working）。”

- 然后你就得自己每隔几秒主动去问一次：“好了吗？好了吗？”（调用 `tasks/get` 查状态）

- 直到对方说：“完成了！”或者“失败了”，你才算拿到结果。

✅ 优点：简单直接，兼容性好（所有系统都支持）。



❌ 缺点：你得一直盯着问，浪费网络和精力；还可能刚问完它就完成了，但你下一次才查到，有延迟。

👉 就像你在餐厅点了一份现烤披萨，每隔30秒就跑厨房门口问一次：“好了没？”

![image\.png](图片和附件/image%206.png)

2）流式传输（服务器发送事件 \- SSE）： 

- 服务端代理返回增量结果，或者提供实时进度更新的任务。 

- 客户端代理使⽤ message/stream 与服务端代理发起交互。 

- 服务端代理保持 HTTP 连接进⾏响应，发送服务器事件（SSE）。 

- 事件可以是 任务 、 消息 ，或者\`TaskStatusUpdateEvent （⽤于状态更改），或者 TaskArtifactUpdateEvent （⽤于新的或更新的⼯件块）。 

- 服务器代理在代理卡中定义 stream 的能⼒。

### 2️⃣ 流式传输（SSE）——像直播进度，边做边告诉你

- 你发起请求时说：“我要用流式模式（`message/stream`）。”

- 服务端不挂电话，而是保持连接打开，像开直播一样：

    - 先发：“开始查航班……”

    - 再发：“酒店推荐已生成”

    - 接着发：“这是行程草稿（文字）”

    - 最后发：“攻略 PDF 已完成（文件）”

这些信息通过 SSE（Server\-Sent Events） 实时推送过来，你不用问，它主动说。

✅ 优点：实时性强，体验流畅，适合需要“边做边看”的场景。



❌ 缺点：需要保持长连接，网络不稳定时容易断；有些防火墙或代理不支持。

👉 就像厨师一边做菜一边用对讲机跟你同步：“现在煎牛排了”“酱汁调好了”“马上装盘！”

![image\.png](图片和附件/image%2010.png)

3）推送通知: 

- 对于⾮常⻓时间运⾏的任务或场景（任务跨越多个系统），或者维持持 久连接（如 SSE）不切实际的情况。 

- 客户在启动任务时（或通过调⽤ tasks/pushNotificationConfig/set ）可以提供⼀个 Webhook URL。 

- 当任务状态发⽣变化（例如完成、失败或需要输⼊）时，服务端代理调⽤客户端 Webhook 发送异步通知（HTTP POST 请求）。 

- 服务器代理在代理卡中定义 pushNotifications 功能。

### 3️⃣ 推送通知（Webhook）——像留个电话，好了打给你

- 你一开始就说：“我不等你，你做好了主动通知我。”

- 你提供一个 回调网址（Webhook URL），比如 `https://your-app.com/task-done`

- 然后你就去干别的事了。

- 等服务端任务完成（或卡住了、需要你确认），它会主动发一个 HTTP 请求到你给的网址，说：“任务 abc123 已完成，请来取结果！”

✅ 优点：完全异步，不占连接，适合超长时间任务（比如几小时、几天），也适合跨系统协作。



❌ 缺点：你需要有个公网能访问的服务来接收通知；配置稍微复杂点。

👉 就像你把衣服送去干洗店，留了个电话，店员洗好后直接打电话：“您的衣服好了，来取吧！”——你不用一直蹲在店门口。

为什么需要支持三种？

因为现实中的 AI 代理协作场景千差万别：

## A2A 和 MCP 如何配合？

### 3\.1 A2A 和 MCP 配合

MCP （Model Context Proctocol）解决⼤模型对⼯具和资源的调⽤， MCP⽤于⼯具。

MCP 专注⼯具和资源： 

1. 通过结构化的⽅式调⽤⼯具和资源，利⽤function call⽅式实现（例如， 

2. 计算器、数据库查询 API、天⽓查找服务）。 

3. ⼤模型通过对⾃然语⾔的判断，决定是否调⽤⼯具或者资源。 

4. 调⽤⼯具或者资源的结果交给⼤模型进⾏润⾊返回⽤户。 

A2A 专注代理协同： 

1. 代理是⾃主的系统。结合推理、计划、⼯具、记忆等多种能⼒完成复杂⼯作，通常需要多轮对话。完成的任务复杂，任务时⻓不可控，采⽤技术不可控。 

2. 需要多个代理参与，代理之间存在多轮交互。 

3. 代理处理任务包含了⼯具和资源的调⽤

![image\.png](图片和附件/image%203.png)



![image\.png](图片和附件/image%205.png)

## A2A 协议如何使用？

A2A官⽅提供的代理例⼦ https://github\.com/a2aproject/a2a\-samples

### 4\.1 A2A 项目环境部署

通过conda 创建开发环境

```Shell
conda create -n a2a python=3.11
```

激活 a2a 的环境

```Shell
conda activate a2a
```

安装相关依赖

```Shell
pip install -r samples/python/requirements.txt
```

安装的依赖内容如下：

```Shell
a2a[http-server]>=0.3.0
uvicorn
```

> a2a\-sdk：这是 Google 官⽅推出的 Agent\-to\-Agent \(A2A\) Protocol 
> 
> Python SDK，⽤于构建多智能体系统，实现模型与模型之间通过统⼀协议进 
> 
> ⾏对话、上下⽂传递和协作。
> 
> uvicorn：是⼀款轻量级且极快的 ASGI Web 服务器，适⽤于运⾏异步Python 应⽤（如 FastAPI、Starlette 等），⽀持 HTTP/1\.1、WebSocket 
> 
> 等协议。
> 
> 

### 4\.2 A2A 项目开发，部署和运行

agent\_executor\.py

```Python
# 导入 A2A 框架中执行代理任务所需的核心类
from a2a.server.agent_execution import AgentExecutor, RequestContext
# 导入用于发送事件（比如消息、进度更新）的队列工具
from a2a.server.events import EventQueue
# 导入一个便捷函数，用来创建一条“由代理发出的文本消息”
from a2a.utils import new_agent_text_message


# --8<-- [start:HelloWorldAgent]
# 定义一个最简单的 AI 代理：它啥也不干，只会说 "Hello World"
class HelloWorldAgent:
    """Hello World Agent."""

    # invoke 是这个代理的核心方法，调用它就会返回一句问候语
    async def invoke(self) -> str:
        return 'Hello World'
# --8<-- [end:HelloWorldAgent]


# --8<-- [start:HelloWorldAgentExecutor_init]
# 这个类是 HelloWorldAgent 的“执行器”——负责在 A2A 系统里运行它
# 它继承自 A2A 提供的标准基类 AgentExecutor
class HelloWorldAgentExecutor(AgentExecutor):
    """Test AgentProxy Implementation."""

    # 初始化时，创建一个 HelloWorldAgent 实例，存起来备用
    def __init__(self):
        self.agent = HelloWorldAgent()
    # --8<-- [end:HelloWorldAgentExecutor_init]

    # --8<-- [start:HelloWorldAgentExecutor_execute]
    # execute 是 A2A 框架调用的核心方法：当有任务进来，就执行这个函数
    async def execute(
        self,
        context: RequestContext,      # 包含任务上下文信息（比如用户ID、任务ID等）
        event_queue: EventQueue,      # 一个“消息通道”，用来把结果或进度发出去
    ) -> None:
        # 调用我们自己的代理，让它干活（这里就是返回 "Hello World"）
        result = await self.agent.invoke()
        # 把结果包装成一条“代理发出的文本消息”，放进事件队列，通知客户端
        # 内容都不是直接 return 给调用者，而是通过 event_queue.enqueue_event(...) “扔进队列”，
        # 由 A2A 框架后台统一处理并按协议规则（轮询/SSE/Webhook）发送给客户端。
        await event_queue.enqueue_event(new_agent_text_message(result))
    # --8<-- [end:HelloWorldAgentExecutor_execute]

    # --8<-- [start:HelloWorldAgentExecutor_cancel]
    # 如果用户中途想取消任务，框架会调用 cancel 方法
    async def cancel(
        self, context: RequestContext, event_queue: EventQueue
    ) -> None:
        # 但这个简单代理不支持取消，所以直接抛个异常（实际项目中可优化）
        raise Exception('cancel not supported')
    # --8<-- [end:HelloWorldAgentExecutor_cancel]
```

☕ 场景：设计一个只会说 “Hello World\!” 的 AI 咖啡师

**🧑‍🍳 1\. ****`HelloWorldAgent`**** → 真正的“AI 咖啡师本人”**

- 这个咖啡师非常特别：他不会做咖啡、不会拉花、甚至不会倒水。

- 但只要你问他：“你好吗？”、“能帮我查汇率吗？”、“给我一杯拿铁？”，
他永远只回答一句：“Hello World\!”

- 他的核心能力就藏在 `invoke()` 方法里——这是他唯一的“技能按钮”。

> 💡 就像一个机器人，出厂设定就是复读机，但复读的内容是程序员定的。
> 
> 

**🧰 2\. ****`HelloWorldAgentExecutor`**** → “AI 咖啡师的操作台 \+ 对讲机系统”**

这个执行器不是咖啡师本人，而是连接咖啡师和整个店铺运营系统的桥梁。它有三个关键功能：

**✅ 初始化（****`init`****）→ 给操作台装上咖啡师**

- 就像开店前，你把那个只会说 “Hello World\!” 的 AI 咖啡师固定安装在后厨的操作台上。

- 以后所有订单来了，都通过这个操作台喊他干活。

**🔧 执行任务（****`execute`****）→ 接单 → 喊话 → 发结果**

- 当店长（`DefaultRequestHandler`）送来一张订单（比如“用户问：10美元兑多少卢比？”），
操作台立刻：

    1. 按下咖啡师的“技能按钮”（调用 `agent.invoke()`）；

    2. 咖啡师大喊：“Hello World\!”；

    3. 操作台不直接把话传给顾客，而是拿起对讲机，把这句话发到中央广播系统（`event_queue`）；

    4. 店里的广播系统（A2A 框架）会自动决定：是打包成一次性消息，还是分段直播给顾客。

> 💡 重点：结果不是 return 出去的，而是“扔进事件队列” —— 这是为了支持流式、异步、多客户端通知。
> 
> 

**🚫 取消任务（****`cancel`****）→ 试图打断咖啡师说话**

- 顾客突然说：“算了，别说了！”

- 但你的 AI 咖啡师是个“一根筋”——一旦开口，必须说完 “Hello World\!” 才停。

- 所以操作台只能无奈回复：“对不起，这位咖啡师不支持中途打断！”

> 💡 实际项目中，复杂任务（如生成长文）会在这里清理资源、终止循环，但“Hello World”太简单，没必要。
> 
> 

**📡 整个协作流程（从顾客下单到收到回复）**

1. 顾客点单 → 店长接单 → 创建任务 → 放入小票夹（`InMemoryTaskStore`）

2. 店长通知后厨：“有新单！请 `HelloWorldAgentExecutor` 处理！”

3. 执行器（操作台）启动：

    - 唤醒 `HelloWorldAgent`（AI 咖啡师）

    - 获取他说的 “Hello World\!”

    - 把这句话塞进 事件队列（对讲机广播系统）

4. A2A 框架监听队列：

    - 如果是普通请求 → 等全部说完，打包回复；

    - 如果是流式请求 → 每个字/词都实时推送（虽然这里只有一句）；

5. 顾客收到结果：“Hello World\!”

**✅ 为什么这样设计？**

- 解耦：咖啡师（业务逻辑）不用知道“怎么对外说话”，只管输出内容；

- 标准化：所有代理都通过 `event_queue` 发消息，框架统一处理协议细节；

- 可扩展：未来换成“会算汇率的咖啡师”，只需换 `agent`，执行器结构不变。

就像麦当劳的后厨：
不管做汉堡还是冰淇淋，都有标准操作台、标准出餐口、标准叫号系统——`AgentExecutor` 就是这个标准化的“AI 后厨工作站”。

---

\_\_main\_\_

```Python
# 导入 uvicorn，这是一个用于运行异步 Python Web 应用的轻量级服务器
import uvicorn
# 从 A2A 框架中导入用于构建符合 A2A 协议的 Starlette 应用的核心类
from a2a.server.apps import A2AStarletteApplication
# 导入默认的请求处理器，它负责解析客户端发来的 A2A 请求并调用对应的代理执行器
from a2a.server.request_handlers import DefaultRequestHandler
# 导入一个基于内存的任务存储实现，用于临时保存任务的状态（适合开发和测试）
from a2a.server.tasks import InMemoryTaskStore
# 从类型模块导入描述代理能力所需的数据结构：代理能力、代理名片、代理技能
from a2a.types import (AgentCapabilities, AgentCard, AgentSkill,)
# 导入我们自己实现的代理执行器（即前面定义的 HelloWorldAgentExecutor），type: ignore 是为了忽略类型检查警告
from agent_executor import (HelloWorldAgentExecutor,  # type: ignore[import-untyped])

# 当这个文件被直接运行时（而不是被其他文件导入），才执行下面的主程序逻辑
if __name__ == '__main__':
    # 定义一个基础技能：ID 为 'hello_world'，表示这个代理能做“返回 Hello World”这件事
    skill = AgentSkill(
        id='hello_world',  # 技能的唯一标识符，其他代理通过这个 ID 调用该技能
        name='Returns hello world',  # 技能的可读名称
        description='just returns hello world',  # 对技能功能的详细说明
        tags=['hello world'],  # 给技能打标签，便于发现和分类
        examples=['hi', 'hello world'],  # 提供调用该技能的示例输入，帮助用户理解怎么用
    )
    # 定义一个扩展技能：只有经过身份验证的用户才能使用的“超级打招呼”功能
    extended_skill = AgentSkill(
        id='super_hello_world',
        name='Returns a SUPER Hello World',
        description='A more enthusiastic greeting, only for authenticated users.',
        tags=['hello world', 'super', 'extended'],
        examples=['super hi', 'give me a super hello'],
    )
    # 创建公开版的代理名片（所有人都能看到的版本）
    public_agent_card = AgentCard(
        name='Hello World Agent',  # 代理的名称
        description='Just a hello world agent',  # 代理的简要描述
        url='http://localhost:9999/',  # 代理服务的根 URL，客户端通过这个地址与之通信
        version='1.0.0',  # 代理的版本号
        default_input_modes=['text'],  # 默认接受的输入类型是文本
        default_output_modes=['text'],  # 默认输出的类型也是文本
        capabilities=AgentCapabilities(streaming=True),  # 声明该代理支持流式传输（如 SSE）
        skills=[skill],  # 公开版只暴露基础技能，隐藏高级功能
        supports_authenticated_extended_card=True,  # 表示：如果用户已认证，还可以提供一张功能更全的名片
    )
    # 基于公开名片复制出一张“认证用户专用”的增强版名片，并更新部分内容
    specific_extended_agent_card = public_agent_card.model_copy(
        update={
            'name': 'Hello World Agent - Extended Edition',  # 改个名字以示区别
            'description': 'The full-featured hello world agent for authenticated users.',  # 更详细的描述
            'version': '1.0.1',  # 可以使用不同的版本号
            # 其他字段（如 url、capabilities、default_input_modes 等）自动继承自 public_agent_card
            'skills': [skill, extended_skill],  # 同时包含基础技能和扩展技能，功能更强大
        }
    )
    # 创建请求处理器实例，它会把收到的 A2A 请求交给 HelloWorldAgentExecutor 处理，并用内存存储任务状态
    request_handler = DefaultRequestHandler(
        agent_executor=HelloWorldAgentExecutor(),  # 使用我们自定义的代理执行器来运行任务
        task_store=InMemoryTaskStore(),  # 任务数据暂存在内存中（重启服务后会丢失，仅用于测试）
    )
    # 构建完整的 A2A Web 应用：绑定公开名片、请求处理器和认证用户的增强名片
    server = A2AStarletteApplication(
        agent_card=public_agent_card,  # 所有人都能看到的代理信息
        http_handler=request_handler,  # 处理 HTTP 请求的实际逻辑
        extended_agent_card=specific_extended_agent_card,  # 已认证用户可访问的完整功能名片
    )
    # 启动 Web 服务：将构建好的应用跑在本机 9999 端口，允许任何 IP 地址访问（0.0.0.0 表示监听所有网络接口）
    uvicorn.run(server.build(), host='0.0.0.0', port=9999)
```

```Shell
A2AStarletteApplication
│
├── 对外提供 /agent.json（代理名片）
├── 注册所有 A2A 标准 API 路由（/tasks, /message/...）
└── 所有业务请求 → 转交给 → DefaultRequestHandler
                              │
                              ├── 调用 HelloWorldAgentExecutor.execute()
                              └── 使用 InMemoryTaskStore 存任务状态
```

定义了两个代理技能（⼲什么）： 

基础技能：返回简单的"hello world"问候\-普通 

扩展技能：返回更热情的问候\-特殊 

创建了两个代理卡⽚（描述服务）：

公共卡⽚：包含基础技能，⾯向所有⽤户 

扩展卡⽚：包含基础技能和扩展技能，⾯向认证⽤户

使⽤A2A框架构建了⼀个Web服务：

使⽤DefaultRequestHandler处理请求 

使⽤InMemoryTaskStore存储任务 

使⽤HelloWorldAgentExecutor执⾏代理逻辑 

通过A2AStarletteApplication包装成Starlette应⽤

最后使⽤uvicorn运⾏服务： 

监听localhost:9999端⼝

**☕ 场景：你开了一家“智能咖啡店”（这就是你的 Web 服务）**

1\. `HelloWorldAgentExecutor` → 咖啡师本人

- 他是真正会做咖啡的人。

- 你问他：“能做杯拿铁吗？”
他只会回答一句：“Hello World！”（在这个例子里，他其实不会做咖啡，只会打招呼 😄）。

- 但他不直接面对顾客，只听从店长安排。

2\. `InMemoryTaskStore` → 店里的点单小票夹（挂在墙上那种）

- 每当有顾客下单，店长就把订单写在小票上，夹在这个夹子上。

- 咖啡师做完一杯，就从小票夹里取下对应的单子。

- 注意：这个夹子是纸质的、临时的——如果店里停电或关门重启，所有小票就丢了（因为是“内存存储”，不是数据库）。

3\. `DefaultRequestHandler` → 店长（负责调度）

- 顾客进门点单，店长接待。

- 他干三件事：

    - 把订单写到小票上，夹进 `InMemoryTaskStore`；

    - 喊一声：“咖啡师，有新单！”（调用 `HelloWorldAgentExecutor.execute()`）；

    - 等咖啡师做好后，把结果（“Hello World\!”）端给顾客。

- 他不管店面装修、招牌怎么挂、要不要会员卡，只管“接单 → 安排做 → 送结果”。

4\. `A2AStarletteApplication` → 整个咖啡店的营业执照 \+ 门头 \+ 菜单牌 \+ 收银系统

- 它决定了：

    - 店名叫什么（`name='Hello World Agent'`）；

    - 菜单上写“本店支持现场观看制作过程”（`streaming=True`）；

    - 挂出公开菜单（`agent_card`），还有一份“会员专享菜单”（`extended_agent_card`）；

    - 所有顾客都通过同一个入口（HTTP 接口）进来；

    - 把真正的接待工作交给店长（`http_handler=request_handler`）。

- 它是对外的完整形象，让路人知道：“这是一家合规、功能明确的智能咖啡店”。

---

**🧾 客户端来点单时发生了什么？**

1. 顾客（客户端）走到店门口，先看菜单（访问 `/.well-known/agent.json`）；

2. 决定点一杯“打招呼咖啡”（发送 `message/send` 请求）；

3. 咖啡店（`A2AStarletteApplication`） 接待顾客，引导到店长那里；

4. 店长（`DefaultRequestHandler`）：

    - 写张小票（存入 `InMemoryTaskStore`）；

    - 叫咖啡师开工；

5. 咖啡师（`HelloWorldAgentExecutor`）：

    - 大喊一声：“Hello World\!”；

    - 把这句话交给店长；

6. 店长把这句话装进杯子，递给顾客——任务完成！

> 如果顾客说：“我要边看边喝！”（流式请求），
> 
> 咖啡师就会分几次喊：“Hel… lo… World… \!”，店长也分几次递纸条给顾客。
> 
> 

**✅ 总结对应关系：**

这样设计的好处是：

- 想换咖啡师？没问题，只要他会说“Hello World”就行；

- 想把小票夹换成电子屏（换成数据库）？店长不用改；

- 想开连锁店？复制整个“咖啡店”模板即可！

这就是 A2A 框架的模块化、标准化、可扩展之美。

test\_client\.py

```Python
# 导入日志模块，用来打印运行过程中的信息（比如“正在连接…”、“收到结果”等）
import logging

# 从 typing 模块导入 Any，表示“任意类型”，用于类型提示
from typing import Any
# 从 uuid 模块导入 uuid4，用于生成唯一的随机 ID（比如消息ID、请求ID）
from uuid import uuid4

# 导入 httpx，这是一个支持异步 HTTP 请求的客户端库（类似 requests，但支持 async/await）
import httpx

# 从 A2A 客户端模块导入两个核心类：
# - A2ACardResolver：用于自动获取远程代理的“名片”（Agent Card）
# - A2AClient：用于向远程代理发送任务请求
from a2a.client import A2ACardResolver, A2AClient
# 从类型定义中导入客户端需要的数据结构
from a2a.types import (
    AgentCard,                # 代理名片的数据结构
    MessageSendParams,        # 发送消息时的参数格式
    SendMessageRequest,       # 一次普通（非流式）消息请求的封装
    SendStreamingMessageRequest,  # 一次流式消息请求的封装
)
# 从常量模块导入 A2A 协议规定的标准路径
from a2a.utils.constants import (
    AGENT_CARD_WELL_KNOWN_PATH,     # 公开代理名片的标准路径：/.well-known/agent.json
    EXTENDED_AGENT_CARD_PATH,       # 认证用户专用名片的路径：/agent-card-extended
)


# 定义主异步函数 main()，整个客户端逻辑都在这里
async def main() -> None:
    # 设置日志级别为 INFO，这样 info/warning/error 级别的日志都会显示出来
    logging.basicConfig(level=logging.INFO)
    # 获取一个专属的日志记录器，名字是当前模块（__name__）
    logger = logging.getLogger(__name__)

    # --8<-- [start:A2ACardResolver]
    # 设置要连接的代理服务地址（就是之前启动的 HelloWorld 服务）
    base_url = 'http://localhost:9999'

    # 创建一个异步 HTTP 客户端（httpx.AsyncClient），用于发起网络请求
    async with httpx.AsyncClient() as httpx_client:
        # 初始化 A2A 名片解析器：它知道怎么从指定地址获取代理的公开或扩展名片
        resolver = A2ACardResolver(
            httpx_client=httpx_client,  # 传入 HTTP 客户端，用于发请求
            base_url=base_url,          # 代理服务的基础 URL
            # agent_card_path 和 extended_agent_card_path 使用默认值（即标准路径）
        )
        # --8<-- [end:A2ACardResolver]

        # 声明一个变量，用来保存最终决定使用的代理名片（可能是公开版，也可能是扩展版）
        final_agent_card_to_use: AgentCard | None = None

        try:
            # 打印日志：准备获取公开名片
            logger.info(
                f'Attempting to fetch public agent card from: {base_url}{AGENT_CARD_WELL_KNOWN_PATH}'
            )
            # 调用 resolver 获取公开名片（默认从 /.well-known/agent.json 读取）
            _public_card = await resolver.get_agent_card()
            # 成功获取后，打印名片内容（格式化成 JSON，方便阅读）
            logger.info('Successfully fetched public agent card:')
            logger.info(_public_card.model_dump_json(indent=2, exclude_none=True))
            # 默认先用公开名片
            final_agent_card_to_use = _public_card
            logger.info('\nUsing PUBLIC agent card for client initialization (default).')

            # 检查公开名片是否声明“支持认证用户的扩展名片”
            if _public_card.supports_authenticated_extended_card:
                try:
                    # 如果支持，就尝试带上认证令牌去获取扩展名片
                    logger.info(
                        f'\nPublic card supports authenticated extended card. Attempting to fetch from: {base_url}{EXTENDED_AGENT_CARD_PATH}'
                    )
                    # 构造带认证头的 HTTP 请求头（这里用 dummy-token 模拟真实 token）
                    auth_headers_dict = {
                        'Authorization': 'Bearer dummy-token-for-extended-card'
                    }
                    # 调用 get_agent_card 并指定路径和认证头，获取扩展名片
                    _extended_card = await resolver.get_agent_card(
                        relative_card_path=EXTENDED_AGENT_CARD_PATH,  # 指定路径 /agent-card-extended
                        http_kwargs={'headers': auth_headers_dict},   # 附带认证头
                    )
                    # 成功获取扩展名片，打印内容
                    logger.info('Successfully fetched authenticated extended agent card:')
                    logger.info(_extended_card.model_dump_json(indent=2, exclude_none=True))
                    # 更新最终使用的名片为扩展版
                    final_agent_card_to_use = _extended_card
                    logger.info('\nUsing AUTHENTICATED EXTENDED agent card for client initialization.')
                except Exception as e_extended:
                    # 如果获取扩展名片失败（比如没权限、服务没实现），就降级回公开名片
                    logger.warning(
                        f'Failed to fetch extended agent card: {e_extended}. Will proceed with public card.',
                        exc_info=True,
                    )
            elif _public_card:
                # 如果公开名片明确说“不支持扩展名片”，就安心用公开版
                logger.info('\nPublic card does not indicate support for an extended card. Using public card.')

        except Exception as e:
            # 如果连公开名片都拿不到，说明服务根本不可用，直接报错退出
            logger.error(f'Critical error fetching public agent card: {e}', exc_info=True)
            raise RuntimeError('Failed to fetch the public agent card. Cannot continue.') from e

        # --8<-- [start:send_message]
        # 用最终确定的代理名片初始化 A2A 客户端
        client = A2AClient(
            httpx_client=httpx_client,           # 复用之前的 HTTP 客户端
            agent_card=final_agent_card_to_use   # 告诉客户端这个代理能干啥、怎么调用
        )
        logger.info('A2AClient initialized.')

        # 构造一条用户消息的内容：角色是 user，内容是一段文本“10美元兑多少卢比？”
        send_message_payload: dict[str, Any] = {
            'message': {
                'role': 'user',  # 表示这是用户发的消息
                'parts': [       # 消息可以包含多个“部分”，这里只有一个文本部分
                    {'kind': 'text', 'text': 'how much is 10 USD in INR?'}
                ],
                'messageId': uuid4().hex,  # 生成唯一消息ID，用于追踪
            },
        }
        # 把 payload 包装成 A2A 协议要求的 SendMessageRequest 格式（带请求ID）
        request = SendMessageRequest(
            id=str(uuid4()),                  # 整个请求的唯一ID
            params=MessageSendParams(**send_message_payload)  # 参数部分
        )

        # 发送普通（非流式）请求，并等待完整响应
        response = await client.send_message(request)
        # 打印返回结果（转成 JSON 格式，去掉空字段）
        print(response.model_dump(mode='json', exclude_none=True))
        # --8<-- [end:send_message]

        # --8<-- [start:send_message_streaming]
        # 再构造一个**流式请求**（同样的内容，但希望边做边返回）
        streaming_request = SendStreamingMessageRequest(
            id=str(uuid4()),                  # 新的请求ID
            params=MessageSendParams(**send_message_payload)  # 同样的消息内容
        )

        # 调用流式发送方法，它返回一个异步迭代器（不是立即结果！）
        stream_response = client.send_message_streaming(streaming_request)

        # 用 async for 循环逐块接收服务器推送的事件（比如进度、中间结果、最终答案）
        async for chunk in stream_response:
            # 每收到一块数据，就打印出来（也是 JSON 格式）
            print(chunk.model_dump(mode='json', exclude_none=True))
        # --8<-- [end:send_message_streaming]


# 当这个文件被直接运行时，启动异步主函数
if __name__ == '__main__':
    # 导入 asyncio，用于运行异步函数
    import asyncio
    # 启动 main() 函数（它会自动处理所有 await 操作）
    asyncio.run(main())
```

你是一位聪明的顾客（客户端），走进一家新开的“智能咖啡店”（A2A 代理服务），想点一杯咖啡，并体验它的全部功能。

**☕ 场景：你作为顾客，去一家“智能咖啡店”点单**

**第一步：先看门口的菜单牌（获取代理名片）**

- 你走到店门口，看到一块标准招牌写着：
“本店菜单请查看：/\.well\-known/agent\.json”（这是 A2A 协议规定的公开名片路径）。

- 你拿出手机（相当于 `A2ACardResolver`），访问这个地址，下载了一份 公开菜单：

    - 店名：Hello World 咖啡

    - 能力：会说 “Hello World\!”

    - 支持边做边看（流式输出）

    - 特别注明：“会员可查看隐藏菜单”

> 💡 这对应代码中的：
> `resolver.get_agent_card()` → 获取 `_public_card`
> 
> 

---

**第二步：尝试刷会员卡看隐藏菜单（获取扩展名片）**

- 你正好有张会员卡（模拟 `Authorization: Bearer dummy-token...`），于是问店员：

> - “我能看看会员专属菜单吗？”
> 
> 

- 店员带你到后门，给你看了 扩展菜单：

    - 新增技能：“SUPER Hello World\!\!\!”

    - 描述：“仅限认证用户，热情加倍！”

- 你决定：就用这份高级菜单点单！

> 💡 对应代码：
> 
> 带 `headers` 调用 `resolver.get_agent_card(relative_card_path=EXTENDED_AGENT_CARD_PATH)`
> 
> 成功后，`final_agent_card_to_use = _extended_card`
> 
> ❗ 如果没会员卡或店员说“没有隐藏菜单”，你就安心用公开菜单——这就是代码里的降级逻辑。
> 
> 

---

**第三步：正式点单（初始化 A2A 客户端）**

- 你拿着最终确定的菜单（`final_agent_card_to_use`），走到收银台。

- 收银系统（`A2AClient`）根据菜单知道：

    - 这家店接受文本输入；

    - 支持普通下单和“边做边看”模式；

    - 请求要发到 `http://localhost:9999/message/send` 等接口。

> 💡 对应：`client = A2AClient(httpx_client, agent_card=...)`
> 
> 

---

**第四步：第一次点单 —— 普通模式（非流式）**

- 你说：“我想知道 10 美元能换多少印度卢比？”（虽然这跟咖啡无关，但这家店只会回答 “Hello World\!” 😅）

- 收银系统生成一张带唯一编号的订单（`request.id = uuid4()`），并记录你的问题（`messageId` 也唯一）。

- 你安静等待……几秒后，店员端来一个杯子，里面只有一张纸条写着：

```Shell
{ "result": "Hello World!" }
```

- 你拍照存档（`print(response...)`）。

> 💡 对应：`await client.send_message(request)`
> 
> 

**第五步：第二次点单 —— “边做边看”模式（流式）**

- 你觉得有趣，又说：“这次我要看着你做！”

- 店员点头，开始“表演”：

    - 先举起牌子：“Hel…”

    - 再举：“lo…”

    - 然后：“World\!”

    - 最后：“🎉 Done\!”

- 你每看到一块牌子，就记下来（`async for chunk in stream_response` → `print(chunk...)`）。

> 💡 这就是流式响应：服务器分多次推送事件，客户端逐块接收，适合长任务或实时反馈。
> 
> 

**🧾 整个流程总结（顾客视角 vs 代码）**

**✅ 为什么这样设计？**

- 标准化：所有智能代理都按同一套“菜单格式”（Agent Card）对外，顾客（客户端）不用重新学习每家店。

- 灵活升级：公开菜单 \+ 会员菜单，兼顾开放性和权限控制。

- 两种体验：普通模式适合简单问答，流式模式适合复杂任务（如写文章、跑代码）。

就像你去星巴克，不管哪家门店，都知道怎么点单、怎么用会员、怎么选堂饮外带——A2A 就是为 AI 代理世界建立的“连锁咖啡店标准” ☕🤖

![image\.png](图片和附件/image%2012.png)

### 4\.3 基于 LangGraph 的A2A 案例实践

需求：

往往在 A2A 中需要通过完成任务来响应客户端代理的请求，但是⼀次对话往往⽆法完成任务。 当任务需要更多消息的时候，就需要更多的⽤户输⼊信息。 

例如：“美元的汇率是多少？”，问题中没有制定美元对什么货币的汇率，就需要通过多轮对话的⽅式再次询问⽤户。 

此时，就需要服务端代理利⽤事件队列和任务状态的⽅式来处理多轮对话，通过判断任务执⾏情况来更新任务状态（input\-required，completed） 

任务执⾏情况和状态的变更通过事件队列完成同步。



agent\.py

```Python
# 导入操作系统模块，用于读取环境变量（如 API 密钥、模型地址等）
import os

# 导入异步可迭代类型，用于支持流式响应（像聊天一样逐步返回结果）
from collections.abc import AsyncIterable

# 导入通用类型和字面量类型，用于类型提示
from typing import Any, Literal

# 导入 httpx 库，用于发送 HTTP 请求（比如调用汇率 API）
import httpx

# 从 LangChain 导入消息类型：AI 助手的消息和工具调用返回的消息
from langchain_core.messages import AIMessage, ToolMessage

# 从 LangChain 导入 tool 装饰器，用于将普通函数注册为 AI 可调用的工具
from langchain_core.tools import tool

# （虽然导入但未使用）用于调用 Google 的 Gemini 模型
from langchain_google_genai import ChatGoogleGenerativeAI

# 用于调用 OpenAI 兼容的大语言模型（包括本地部署的模型）
from langchain_openai import ChatOpenAI

# 导入内存检查点保存器，用于记住不同用户的对话历史
from langgraph.checkpoint.memory import MemorySaver

# 快速创建一个能“思考+调用工具”的智能体（ReAct 模式）
from langgraph.prebuilt import create_react_agent

# 用于定义结构化数据模型（比如规定响应格式）
from pydantic import BaseModel


# 创建一个内存检查点实例，用来保存每个用户的对话状态（通过 context_id 区分）
memory = MemorySaver()


# 使用 @tool 装饰器将函数注册为 AI 可调用的工具
@tool
def get_exchange_rate(
    currency_from: str = 'USD',      # 默认从美元开始换
    currency_to: str = 'EUR',        # 默认换成欧元
    currency_date: str = 'latest',   # 默认查最新汇率
):
    """Use this to get current exchange rate.

    Args:
        currency_from: 要兑换的源货币（如 "USD"）
        currency_to: 目标货币（如 "INR"）
        currency_date: 查询日期，"latest" 表示最新汇率

    Returns:
        包含汇率数据的字典，或错误信息
    """
    try:
        # 向 Frankfurter 汇率 API 发送 GET 请求（免费公开接口）
        response = httpx.get(
            f'https://api.frankfurter.app/{currency_date}',
            params={'from': currency_from, 'to': currency_to},
        )
        # 如果 HTTP 请求失败（如 404、500），抛出异常
        response.raise_for_status()

        # 将响应解析为 JSON 格式
        data = response.json()
        # 检查返回数据是否包含 'rates' 字段（正常应有）
        if 'rates' not in data:
            return {'error': 'Invalid API response format.'}
        # 返回完整的汇率数据（例如：{'date': '2025-11-24', 'rates': {'INR': 89.64}}）
        return data
    except httpx.HTTPError as e:
        # 捕获网络请求错误（如超时、连接失败）
        return {'error': f'API request failed: {e}'}
    except ValueError:
        # 捕获 JSON 解析失败（比如返回了 HTML 错误页）
        return {'error': 'Invalid JSON response from API.'}


# 定义 AI 最终输出的结构化格式
class ResponseFormat(BaseModel):
    """规定 AI 回复必须包含状态和消息内容"""
    
    # 状态只能是以下三种之一：
    # - input_required：需要用户补充信息
    # - completed：任务成功完成
    # - error：处理过程中出错
    status: Literal['input_required', 'completed', 'error'] = 'input_required'
    # 实际回复给用户的文字内容
    message: str


# 定义一个专门处理货币兑换的智能体类
class CurrencyAgent:
    """CurrencyAgent - 一个只负责查汇率的 AI 助手"""

    # 系统指令：告诉 AI 它的角色和限制
    SYSTEM_INSTRUCTION = (
        'You are a specialized assistant for currency conversions. '
        "Your sole purpose is to use the 'get_exchange_rate' tool to answer questions about currency exchange rates. "
        'If the user asks about anything other than currency conversion or exchange rates, '
        'politely state that you cannot help with that topic and can only assist with currency-related queries. '
        'Do not attempt to answer unrelated questions or use tools for other purposes.'
    )

    # 格式指令：指导 AI 如何设置最终响应的状态
    FORMAT_INSTRUCTION = (
        'Set response status to input_required if the user needs to provide more information to complete the request.'
        'Set response status to error if there is an error while processing the request.'
        'Set response status to completed if the request is complete.'
    )

    def __init__(self):
        # 初始化大语言模型（从环境变量读取配置）
        self.model = ChatOpenAI(
            model=os.getenv('TOOL_LLM_NAME'),           # 模型名称（如 'gpt-4' 或本地模型名）
            openai_api_key=os.getenv('API_KEY', 'EMPTY'),  # API 密钥，默认为 'EMPTY'（兼容本地模型）
            openai_api_base=os.getenv('TOOL_LLM_URL'),  # API 基础地址（如本地 vLLM 或 Ollama 地址）
            temperature=0,  # 温度设为 0，让回答更确定、不胡说
        )
        # 注册可用工具列表（目前只有查汇率一个工具）
        self.tools = [get_exchange_rate]

        # 创建智能体：结合模型、工具、记忆、系统提示和响应格式
        self.graph = create_react_agent(
            self.model,                  # 使用的语言模型
            tools=self.tools,            # 可调用的工具
            checkpointer=memory,         # 对话记忆存储
            prompt=self.SYSTEM_INSTRUCTION,  # 角色设定
            response_format=(self.FORMAT_INSTRUCTION, ResponseFormat),  # 要求最终输出符合 ResponseFormat
        )

    # 异步流式响应方法：边执行边返回中间状态
    async def stream(self, query, context_id) -> AsyncIterable[dict[str, Any]]:
        # 准备输入：把用户问题包装成消息列表
        inputs = {'messages': [('user', query)]}
        # 配置会话 ID，用于区分不同用户的对话历史
        config = {'configurable': {'thread_id': context_id}}

        # 让智能体逐步执行（可能包括思考、调用工具、生成答案）
        for item in self.graph.stream(inputs, config, stream_mode='values'):
            # 获取当前步骤的最后一条消息
            message = item['messages'][-1]
            # 如果是 AI 决定要调用工具（比如准备查汇率）
            if (
                isinstance(message, AIMessage)
                and message.tool_calls
                and len(message.tool_calls) > 0
            ):
                # 返回“正在查询”提示
                yield {
                    'is_task_complete': False,      # 任务未完成
                    'require_user_input': False,    # 不需要用户输入
                    'content': 'Looking up the exchange rates...',
                }
            # 如果是工具调用返回的结果（比如拿到了汇率数据）
            elif isinstance(message, ToolMessage):
                # 返回“正在处理”提示
                yield {
                    'is_task_complete': False,
                    'require_user_input': False,
                    'content': 'Processing the exchange rates..',
                }

        # 所有步骤完成后，获取并返回最终答案
        yield self.get_agent_response(config)

    # 获取智能体最终响应的方法
    def get_agent_response(self, config):
        # 从智能体状态中读取当前结果
        current_state = self.graph.get_state(config)
        # 尝试获取结构化响应（即符合 ResponseFormat 的对象）
        structured_response = current_state.values.get('structured_response')
        # 如果确实拿到了规范格式的响应
        if structured_response and isinstance(
            structured_response, ResponseFormat
        ):
            # 如果状态是“需要更多信息”
            if structured_response.status == 'input_required':
                return {
                    'is_task_complete': False,
                    'require_user_input': True,     # 需要用户补充信息
                    'content': structured_response.message,
                }
            # 如果状态是“出错”
            if structured_response.status == 'error':
                return {
                    'is_task_complete': False,
                    'require_user_input': True,     # 提示用户可能需重试
                    'content': structured_response.message,
                }
            # 如果状态是“完成”
            if structured_response.status == 'completed':
                return {
                    'is_task_complete': True,       # 任务已完成
                    'require_user_input': False,
                    'content': structured_response.message,
                }

        # 如果连结构化响应都没有（异常兜底）
        return {
            'is_task_complete': False,
            'require_user_input': True,
            'content': (
                'We are unable to process your request at the moment. '
                'Please try again.'
            ),
        }

    # 声明该智能体只支持纯文本输入/输出
    SUPPORTED_CONTENT_TYPES = ['text', 'text/plain']
```

这个 `CurrencyAgent` 就像是银行里一个只会查汇率的智能客服机器人——你问它“10美元换多少人民币”，它会一步步告诉你“正在查…正在算…结果是72元”；如果你没说清楚换哪种货币，它会问你“请问换成什么币？”；如果你问天气，它会说“我只会查汇率哦”；如果网络断了，它也会诚实地告诉你“现在查不了，请稍后再试”。而且它还能记住你上一句说了什么，实现连续对话。



agent\_executor\.py

```Python
# 导入日志模块，用于记录程序运行信息（比如“开始处理请求”、“出错了”等）
import logging

# 从 a2a 框架导入核心执行组件：
# - AgentExecutor：所有智能体执行器的基类
# - RequestContext：封装当前用户请求的上下文（包含消息、任务、输入等）
from a2a.server.agent_execution import AgentExecutor, RequestContext

# 事件队列：用于将智能体的每一步操作（如回复消息、更新状态）推送给客户端
from a2a.server.events import EventQueue

# 任务更新器：专门用来更新任务状态（比如“进行中”、“等待输入”、“已完成”）
from a2a.server.tasks import TaskUpdater

# 从 a2a 类型系统导入各种标准错误和数据结构
from a2a.types import (
    InternalError,           # 内部服务器错误（比如代码崩溃）
    InvalidParamsError,      # 用户输入参数无效（比如格式不对）
    Part,                    # 通用内容片段（可包含文本、图片等）
    TaskState,               # 任务状态枚举（如 working, input_required, completed）
    TextPart,                # 纯文本内容片段
    UnsupportedOperationError,  # 不支持的操作（比如取消任务）
)

# 工具函数：用于创建标准格式的消息和任务对象
from a2a.utils import (
    new_agent_text_message,  # 创建一条 AI 助手发送的文本消息
    new_task,                # 创建一个新任务（当用户首次提问时）
)

# 错误包装类：将内部异常转换为符合 A2A 协议的错误响应
from a2a.utils.errors import ServerError

# 导入我们自己写的汇率智能体（前面定义的 CurrencyAgent）
from app.agent import CurrencyAgent


# 配置日志级别为 INFO，这样 info、warning、error 等日志都会打印出来
logging.basicConfig(level=logging.INFO)

# 获取当前模块的日志记录器，方便后续打日志
logger = logging.getLogger(__name__)


# 定义一个具体的智能体执行器，专门用于处理 CurrencyAgent 的请求
class CurrencyAgentExecutor(AgentExecutor):
    """Currency Conversion AgentExecutor Example.
    
    这个类负责把用户的请求交给 CurrencyAgent 处理，并按 A2A 协议规范返回结果。
    """

    def __init__(self):
        # 初始化时创建一个 CurrencyAgent 实例（即那个只会查汇率的 AI）
        self.agent = CurrencyAgent()

    # 异步执行方法：这是 A2A 框架调用的核心入口
    async def execute(
        self,
        context: RequestContext,   # 包含用户输入、当前任务等信息
        event_queue: EventQueue,   # 用于向客户端推送事件（如消息、状态更新）
    ) -> None:
        # 第一步：验证用户请求是否合法
        error = self._validate_request(context)
        if error:
            # 如果验证失败，抛出“参数无效”错误（但目前 _validate_request 总是返回 False，所以这行不会触发）
            raise ServerError(error=InvalidParamsError())

        # 从上下文中提取用户输入的文本（比如“10美元换多少人民币？”）
        query = context.get_user_input()
        
        # 获取当前任务（一次对话可能对应一个任务）
        task = context.current_task
        
        # 如果没有任务（比如用户第一次提问），就创建一个新任务
        if not task:
            task = new_task(context.message)  # type: ignore
            # 把新任务事件推送给客户端（告诉客户端：“有个新任务开始了”）
            await event_queue.enqueue_event(task)
        
        # 创建任务更新器，用于后续更新该任务的状态和消息
        updater = TaskUpdater(event_queue, task.id, task.context_id)
        
        try:
            # 让 CurrencyAgent 流式处理用户问题，并逐步返回中间结果
            async for item in self.agent.stream(query, task.context_id):
                # 从流式结果中提取关键字段
                is_task_complete = item['is_task_complete']     # 任务是否最终完成？
                require_user_input = item['require_user_input'] # 是否需要用户补充信息？

                # 情况1：任务还在进行中，且不需要用户输入（比如正在查汇率）
                if not is_task_complete and not require_user_input:
                    # 更新任务状态为“working”（工作中），并发送一条提示消息（如“正在查询...”）
                    await updater.update_status(
                        TaskState.working,
                        new_agent_text_message(
                            item['content'],        # 消息内容
                            task.context_id,        # 会话 ID
                            task.id,                # 任务 ID
                        ),
                    )
                
                # 情况2：需要用户补充信息（比如没说换成哪种货币）
                elif require_user_input:
                    # 更新任务状态为“input_required”（等待输入），并发送提示消息
                    await updater.update_status(
                        TaskState.input_required,
                        new_agent_text_message(
                            item['content'],
                            task.context_id,
                            task.id,
                        ),
                        final=True,  # 标记这是本轮交互的最终状态（等待用户回复）
                    )
                    break  # 停止处理，等待用户下一次输入
                
                # 情况3：任务成功完成（比如已算出“10美元=72元人民币”）
                else:
                    # 将最终结果作为“工件”（artifact）保存（便于后续引用或展示）
                    await updater.add_artifact(
                        [Part(root=TextPart(text=item['content']))],  # 包装成标准文本片段
                        name='conversion_result',  # 工件名称
                    )
                    # 标记任务为“completed”（已完成）
                    await updater.complete()
                    break  # 结束处理

        # 如果处理过程中发生任何异常（比如网络错误、代码 bug）
        except Exception as e:
            # 记录错误日志，方便排查问题
            logger.error(f'An error occurred while streaming the response: {e}')
            # 向客户端返回“内部服务器错误”
            raise ServerError(error=InternalError()) from e

    # 请求验证方法（目前未实现有效逻辑）
    def _validate_request(self, context: RequestContext) -> bool:
        # 返回 False 表示“没有错误”，即总是通过验证
        # （如果未来想检查输入长度、格式等，可以在这里加逻辑）
        return False

    # 取消任务的方法（目前不支持）
    async def cancel(
        self, context: RequestContext, event_queue: EventQueue
    ) -> None:
        # 直接抛出“不支持的操作”错误（因为这个智能体无法中途取消）
        raise ServerError(error=UnsupportedOperationError())
```

想象你在使用一个银行官方 App 的汇率查询功能：

- 你输入：“10美元能换多少人民币？”

    - App 显示：“正在查询汇率…” → “正在计算…” → 最后弹出：“10美元 ≈ 72元人民币” ✅

    - 这就是 `execute` 方法在做的事：调用 `CurrencyAgent`，一步步把状态和结果推送给 App。

- 你只输入：“1美元等于多少？”

    - App 回复：“请问您要换成哪种货币？例如欧元、日元或人民币。” 🔄

    - 这时任务状态变成 `input_required`，App 会等待你补充“人民币”后再继续。

- 如果你突然点“取消”，App 提示：“当前操作不支持取消。” ⛔

    - 因为 `cancel` 方法直接报错，表示这个功能还没实现（或没必要实现）。

- 如果银行的汇率服务器宕机了，App 会显示：“服务暂时不可用，请稍后再试。” ❌

    - 这就是 `except Exception` 捕获错误后返回 `InternalError` 的效果。

> 总结：`CurrencyAgentExecutor` 就像是连接用户 App 和后台汇率 AI 的“调度员”。它接收用户请求，指挥 `CurrencyAgent` 工作，并严格按照 A2A 协议把每一步进展（查汇率、等输入、出结果、报错）实时推送给前端，确保用户体验流畅、规范。
> 
> 

\_\_main\_\_\.py

```Python
# 导入日志模块，用于记录程序运行状态（如启动成功、缺少配置等）
import logging

# 导入操作系统接口，用于读取环境变量（如 API 地址、模型名等）
import os

# 导入系统模块，用于在出错时安全退出程序
import sys

# 导入 Click 库，用于创建命令行界面（比如通过 `--host` 和 `--port` 设置参数）
import click

# 导入 httpx 异步 HTTP 客户端，用于发送网络请求（比如推送通知）
import httpx

# 导入 Uvicorn，一个高性能 ASGI 服务器，用于运行 FastAPI/Starlette 应用
import uvicorn

# 从 a2a 框架导入核心应用类：A2AStarletteApplication 是符合 A2A 协议的 Web 服务入口
from a2a.server.apps import A2AStarletteApplication

# 默认请求处理器：负责接收用户请求并交给智能体执行器处理
from a2a.server.request_handlers import DefaultRequestHandler

# 推送通知和任务存储相关组件（内存版，适合开发测试）
from a2a.server.tasks import (
    BasePushNotificationSender,              # 用于向客户端推送实时消息
    InMemoryPushNotificationConfigStore,     # 内存中保存用户的推送配置（如 WebSocket 连接）
    InMemoryTaskStore,                       # 内存中保存任务状态（如“进行中”、“已完成”）
)

# A2A 协议定义的标准数据结构：描述智能体的能力、技能卡片等
from a2a.types import (
    AgentCapabilities,  # 智能体支持的功能（如是否支持流式响应、推送通知）
    AgentCard,          # 智能体的“名片”，包含名称、描述、技能等信息
    AgentSkill,         # 智能体的一项具体能力（如“查汇率”）
)

# 从 dotenv 加载 .env 文件中的环境变量（方便本地开发配置）
from dotenv import load_dotenv

# 导入我们自己实现的汇率智能体和它的执行器
from app.agent import CurrencyAgent
from app.agent_executor import CurrencyAgentExecutor


# 自动加载项目根目录下的 .env 文件中的环境变量（如 TOOL_LLM_URL=...）
load_dotenv()

# 配置日志输出级别为 INFO，这样 info、warning、error 都会显示
logging.basicConfig(level=logging.INFO)

# 获取当前模块的日志记录器，用于打印带模块名的日志
logger = logging.getLogger(__name__)


# 自定义异常：当缺少必要环境变量时抛出
class MissingAPIKeyError(Exception):
    """Exception for missing API key."""
    pass  # 只是一个标记类，表示“缺少关键配置”


# 定义一个命令行命令（通过 `click` 实现）
@click.command()
# 允许用户通过 --host 指定监听的主机地址，默认是 'localhost'
@click.option('--host', 'host', default='localhost')
# 允许用户通过 --port 指定监听的端口号，默认是 10001
@click.option('--port', 'port', default=10001)
def main(host, port):
    """Starts the Currency Agent server."""
    try:
        # 检查是否设置了大模型的 API 地址（比如本地 LLM 服务的 URL）
        if not os.getenv('TOOL_LLM_URL'):
            raise MissingAPIKeyError(
                'TOOL_LLM_URL environment variable not set.'
            )
        # 检查是否设置了要使用的模型名称（如 'gpt-4' 或 'qwen-max'）
        if not os.getenv('TOOL_LLM_NAME'):
            raise MissingAPIKeyError(
                'TOOL_LLM_NAME environment variable not set.'  # 修复原文拼写错误：原为 "environment not variable"
            )

        # 声明该智能体支持的能力：
        # - streaming=True：支持边思考边回复（流式输出）
        # - push_notifications=True：支持主动推送消息给客户端（如任务更新）
        capabilities = AgentCapabilities(streaming=True, push_notifications=True)

        # 定义智能体的一项具体技能：“查汇率”
        skill = AgentSkill(
            id='convert_currency',                             # 技能唯一标识
            name='Currency Exchange Rates Tool',               # 技能名称
            description='Helps with exchange values between various currencies',  # 描述
            tags=['currency conversion', 'currency exchange'], # 标签，便于分类
            examples=['What is exchange rate between USD and GBP?'],  # 使用示例
        )

        # 创建智能体的“电子名片”（AgentCard），供客户端发现和调用
        agent_card = AgentCard(
            name='Currency Agent',                             # 名称
            description='Helps with exchange rates for currencies',  # 简介
            url=f'http://{host}:{port}/',                      # 服务地址
            version='1.0.0',                                   # 版本号
            default_input_modes=CurrencyAgent.SUPPORTED_CONTENT_TYPES,  # 支持的输入类型（纯文本）
            default_output_modes=CurrencyAgent.SUPPORTED_CONTENT_TYPES, # 支持的输出类型（纯文本）
            capabilities=capabilities,                         # 支持的能力
            skills=[skill],                                    # 提供的技能列表
        )

        # --8<-- [start:DefaultRequestHandler]
        # 创建一个异步 HTTP 客户端，用于后续发送推送通知（如通过 Webhook）
        httpx_client = httpx.AsyncClient()

        # 创建内存版的推送配置存储（保存每个用户的推送设置，如回调 URL）
        push_config_store = InMemoryPushNotificationConfigStore()

        # 创建推送通知发送器，绑定 HTTP 客户端和配置存储
        push_sender = BasePushNotificationSender(
            httpx_client=httpx_client,
            config_store=push_config_store
        )

        # 创建默认请求处理器：
        # - 使用我们自定义的 CurrencyAgentExecutor 来执行任务
        # - 使用内存任务存储（InMemoryTaskStore）记录任务状态
        # - 绑定推送配置和发送器，支持实时通知
        request_handler = DefaultRequestHandler(
            agent_executor=CurrencyAgentExecutor(),
            task_store=InMemoryTaskStore(),
            push_config_store=push_config_store,
            push_sender=push_sender
        )

        # 创建 A2A 协议兼容的 Web 应用
        server = A2AStarletteApplication(
            agent_card=agent_card,       # 智能体名片
            http_handler=request_handler # 请求处理逻辑
        )

        # 启动 Web 服务：使用 Uvicorn 运行 Starlette 应用
        uvicorn.run(server.build(), host=host, port=port)
        # --8<-- [end:DefaultRequestHandler]

    # 如果缺少必要环境变量，记录错误并退出
    except MissingAPIKeyError as e:
        logger.error(f'Error: {e}')
        sys.exit(1)  # 退出码 1 表示“配置错误”

    # 如果发生其他未预期的异常（如端口被占用、依赖缺失等）
    except Exception as e:
        logger.error(f'An error occurred during server startup: {e}')
        sys.exit(1)  # 退出码 1 表示“启动失败”


# 当直接运行此脚本时（而不是被导入），执行 main 函数
if __name__ == '__main__':
    main()
```

test\_client\.py

```Python
# 导入日志模块，用于在运行时打印提示、警告或错误信息，方便调试和观察程序行为
import logging

# 导入通用类型 Any，表示变量可以是任意类型（灵活但需谨慎使用）
from typing import Any

# 导入 uuid4 函数，用于生成全球唯一的随机 ID（比如消息ID、请求ID），避免重复
from uuid import uuid4

# 导入 httpx 异步 HTTP 客户端库，用于向远程服务（如智能体服务器）发送网络请求
import httpx

# 从 a2a 客户端库导入两个核心工具类：
# - A2ACardResolver：用于自动获取智能体的“能力说明书”（Agent Card）
# - A2AClient：用于向智能体发送消息并接收回复
from a2a.client import A2ACardResolver, A2AClient

# 从 a2a 类型定义模块导入所需的数据结构：
# - AgentCard：智能体的能力描述文件（类似电子名片）
# - MessageSendParams：发送消息时的参数格式
# - SendMessageRequest：一次完整的消息请求封装（用于普通回复）
# - SendStreamingMessageRequest：一次流式消息请求封装（用于逐步返回结果）
from a2a.types import (
    AgentCard,
    MessageSendParams,
    SendMessageRequest,
    SendStreamingMessageRequest,
)

# 从常量模块导入 A2A 协议规定的标准路径：
# - AGENT_CARD_WELL_KNOWN_PATH：公开智能体名片的标准访问路径（通常是 /.well-known/agent-card.json）
# - EXTENDED_AGENT_CARD_PATH：需要认证的扩展名片路径（通常是 /extended-agent-card）
from a2a.utils.constants import (
    AGENT_CARD_WELL_KNOWN_PATH,
    EXTENDED_AGENT_CARD_PATH,
)


# 定义主异步函数 main，整个客户端测试流程都在这里执行
async def main() -> None:
    # 配置日志系统，设置最低显示级别为 INFO（会显示 info、warning、error 等日志）
    logging.basicConfig(level=logging.INFO)
    # 获取当前模块的日志记录器，方便后续打带模块名的日志
    logger = logging.getLogger(__name__)

    # --8<-- [start:A2ACardResolver]
    
    # 指定智能体服务运行的地址（本地 10001 端口，与服务端启动端口一致）
    base_url = 'http://localhost:10001'

    # 创建一个异步 HTTP 客户端，设置总超时和读取超时均为 60 秒，防止请求卡死
    async with httpx.AsyncClient(timeout=httpx.Timeout(60.0, read=60.0)) as httpx_client:
        # 初始化“智能体名片解析器”，它能帮我们自动从服务器拉取智能体的能力说明
        resolver = A2ACardResolver(
            httpx_client=httpx_client,  # 使用上面创建的 HTTP 客户端
            base_url=base_url,          # 智能体服务的基础 URL
            # agent_card_path 和 extended_agent_card_path 使用默认值（即标准路径）
        )
        # --8<-- [end:A2ACardResolver]

        # 声明一个变量，用于保存最终要使用的智能体名片（可能是公开版或扩展版）
        final_agent_card_to_use: AgentCard | None = None

        try:
            # 打印日志：准备从标准公开路径获取智能体名片
            logger.info(
                f'Attempting to fetch public agent card from: {base_url}{AGENT_CARD_WELL_KNOWN_PATH}'
            )
            # 调用解析器获取公开名片（默认访问 /.well-known/agent-card.json）
            _public_card = (
                await resolver.get_agent_card()
            )  # 从默认公开路径拉取
            # 打印成功获取的日志
            logger.info('Successfully fetched public agent card:')
            # 将名片内容以格式化 JSON 形式打印出来（去掉空字段，缩进2格，便于阅读）
            logger.info(
                _public_card.model_dump_json(indent=2, exclude_none=True)
            )
            # 默认先使用公开名片
            final_agent_card_to_use = _public_card
            logger.info(
                '\nUsing PUBLIC agent card for client initialization (default).'
            )

            # 检查公开名片是否声明“支持认证后的扩展名片”
            if _public_card.supports_authenticated_extended_card:
                try:
                    # 如果支持，就尝试用 token 获取更详细的扩展名片
                    logger.info(
                        '\nPublic card supports authenticated extended card. '
                        'Attempting to fetch from: '
                        f'{base_url}{EXTENDED_AGENT_CARD_PATH}'
                    )
                    # 构造一个模拟的认证请求头（实际项目中应使用真实 token）
                    auth_headers_dict = {
                        'Authorization': 'Bearer dummy-token-for-extended-card'
                    }
                    # 再次调用解析器，但这次指定路径为扩展名片路径，并带上认证头
                    _extended_card = await resolver.get_agent_card(
                        relative_card_path=EXTENDED_AGENT_CARD_PATH,  # 指定非默认路径
                        http_kwargs={'headers': auth_headers_dict},   # 附加 HTTP 请求参数
                    )
                    # 打印成功获取扩展名片的日志
                    logger.info(
                        'Successfully fetched authenticated extended agent card:'
                    )
                    # 格式化打印扩展名片内容
                    logger.info(
                        _extended_card.model_dump_json(
                            indent=2, exclude_none=True
                        )
                    )
                    # 更新为使用扩展名片（因为它可能包含更多私有技能）
                    final_agent_card_to_use = (
                        _extended_card
                    )
                    logger.info(
                        '\nUsing AUTHENTICATED EXTENDED agent card for client '
                        'initialization.'
                    )
                except Exception as e_extended:
                    # 如果获取扩展名片失败，记录警告，但不中断流程，继续用公开名片
                    logger.warning(
                        f'Failed to fetch extended agent card: {e_extended}. '
                        'Will proceed with public card.',
                        exc_info=True,  # 同时打印完整的错误堆栈，便于排查
                    )
            elif (
                _public_card
            ):  # 如果公开名片存在，但明确不支持或未声明支持扩展名片
                logger.info(
                    '\nPublic card does not indicate support for an extended card. Using public card.'
                )

        except Exception as e:
            # 如果连公开名片都拿不到，说明服务没启动或网络不通，属于严重错误
            logger.error(
                f'Critical error fetching public agent card: {e}', exc_info=True
            )
            # 抛出运行时错误，终止程序
            raise RuntimeError(
                'Failed to fetch the public agent card. Cannot continue.'
            ) from e

        # --8<-- [start:send_message]
        # 使用最终确定的智能体名片初始化 A2A 客户端（它知道如何与该智能体对话）
        client = A2AClient(
            httpx_client=httpx_client, agent_card=final_agent_card_to_use
        )

        # （以下两行是另一种创建客户端的方式，目前被注释掉，未启用）
        # from a2a.client import ClientFactory
        # client = ClientFactory.create_client(agent_card=card, timeout=60)

        # 记录客户端初始化成功的日志
        logger.info('A2AClient initialized.')

        # 构造第一条用户消息的内容：询问“10美元换多少印度卢比？”
        send_message_payload: dict[str, Any] = {
            'message': {
                'role': 'user',                     # 角色是用户（不是系统或助手）
                'parts': [                          # 消息由多个“片段”组成（这里只有一个文本片段）
                    {'kind': 'text', 'text': 'how much is 10 USD in INR?'}
                ],
                'message_id': uuid4().hex,         # 生成唯一消息ID（十六进制字符串，确保不重复）
            },
        }
        # 将消息包装成符合 A2A 协议的完整请求对象
        request = SendMessageRequest(
            id=str(uuid4()),                       # 整个请求的全局唯一ID
            params=MessageSendParams(**send_message_payload)  # 填入消息参数
        )

        # 发送消息并等待服务器返回完整响应（非流式，一次性返回）
        response = await client.send_message(request)
        # 打印服务器返回的 JSON 结果（去掉空字段，便于阅读）
        print(response.model_dump(mode='json', exclude_none=True))
        # --8<-- [end:send_message]

        # --8<-- [start:Multiturn]
        # 构造一个多轮对话的第一条消息：只问“1美元汇率是多少？”，但没说换成什么币
        send_message_payload_multiturn: dict[str, Any] = {
            'message': {
                'role': 'user',
                'parts': [
                    {
                        'kind': 'text',
                        'text': 'How much is the exchange rate for 1 USD?',
                    }
                ],
                'message_id': uuid4().hex,
            },
        }
        # 包装成请求对象
        request = SendMessageRequest(
            id=str(uuid4()),
            params=MessageSendParams(**send_message_payload_multiturn),
        )

        # 发送第一轮消息
        response = await client.send_message(request)
        # 打印响应
        print(response.model_dump(mode='json', exclude_none=True))

        # 从响应中提取任务ID和上下文ID（用于关联后续对话，实现“记住上下文”）
        task_id = response.root.result.id
        context_id = response.root.result.context_id

        # 构造第二轮消息：用户补充“换成加元（CAD）”
        second_send_message_payload_multiturn: dict[str, Any] = {
            'message': {
                'role': 'user',
                'parts': [{'kind': 'text', 'text': 'CAD'}],
                'message_id': uuid4().hex,
                'task_id': task_id,        # 关键：带上上一轮的任务ID
                'context_id': context_id,  # 关键：带上上一轮的上下文ID
            },
        }

        # 包装第二轮请求
        second_request = SendMessageRequest(
            id=str(uuid4()),
            params=MessageSendParams(**second_send_message_payload_multiturn),
        )

        # 发送第二轮消息
        second_response = await client.send_message(second_request)
        # 打印第二轮响应
        print(second_response.model_dump(mode='json', exclude_none=True))
        # --8<-- [end:Multiturn]

        # --8<-- [start:send_message_streaming]
        # 再次发送最初的问题，但这次要求“流式回复”（像真人打字一样逐步输出）
        streaming_request = SendStreamingMessageRequest(
            id=str(uuid4()), 
            params=MessageSendParams(**send_message_payload)  # 复用第一条消息内容
        )

        # 调用流式发送方法，返回一个异步可迭代对象（数据流）
        stream_response = client.send_message_streaming(streaming_request)

        # 逐块接收服务器返回的内容（每收到一块就打印一次）
        async for chunk in stream_response:
            print(chunk.model_dump(mode='json', exclude_none=True))
        # --8<-- [end:send_message_streaming]


# 如果这个文件被直接运行（而不是被其他文件导入），就启动异步主函数
if __name__ == '__main__':
    import asyncio  # 导入异步事件循环管理模块

    # 启动 asyncio 事件循环，运行 main 函数
    asyncio.run(main())
```

🌟 生活中的例子说明

想象你正在使用一个智能客服机器人（比如银行的汇率助手），而这段代码就是你在后台测试这个机器人是否正常工作的“遥控器”。

1. 第一步：看说明书
你先问机器人：“你能干什么？”
→ 它给你一份《公开说明书》：“我会查汇率。”
→ 你还试着用员工卡刷一下，看能不能拿到《内部高级说明书》，结果发现不需要，就继续用公开版。

2. 第二步：单次提问
你问：“10美元换多少印度卢比？”
→ 机器人思考后，直接告诉你答案 ✅

3. 第三步：多轮对话
你故意只说：“1美元汇率多少？”
→ 机器人回：“请问换成哪种货币？”
→ 你接着说：“加元。”
→ 机器人立刻回答：“1美元 ≈ 1\.37 加元。”
→ 关键：它记得这是同一个问题，没有当成两个独立问题！

4. 第四步：边想边说（流式）
你再次提问，但要求“边查边说”。
→ 屏幕上依次出现：
“正在查询…” → “获取到最新汇率…” → “10美元 = 835\.20 INR”
→ 就像真人打字一样，让你感觉它在“实时思考”。

> 总结：这段代码是一个完整的 A2A 智能体客户端测试脚本。它模拟了真实用户与智能体交互的所有典型场景——获取能力说明、单轮问答、多轮上下文对话、流式响应——确保你开发的智能体服务符合 A2A 协议规范，能被任何兼容的前端（App、网页、语音助手）无缝调用。
> 
> 



