# Claude Code实操\-文档审核Agent

# 0\. 开发流程

本项目将以 **SDD（Specification\-Driven Development，规范驱动开发）** 为核心开发模式，严格按照流程图中的阶段顺序推进：从基础环境配置与项目初始化起步，通过市场调研、竞品拆解完成业务建模与交互设计；再基于业务规范输出产品原型、PRD 文档与 UI 设计，同步完成后端架构、数据模型与 API 接口定义；最终依托清晰的项目子集规范，完成前后端 MVP 实现、联调验证，并输出 Docker 部署方案。全程以 “先定规范、再写代码” 的方式，确保每一步开发都有明确的设计依据，实现流程的标准化落地。

![image\.png](图片和附件/image%201.png)

# 基础环境配置

![image\.png](图片和附件/image%205.png)

## Step1 配置项目运行环境

找一个电脑里面的位置，新建一个空的文件夹，作为项目名。如：DocAuditAgent

```Plain Text
请启用 claude-code-guide 详细了解 Agent Teams 的配置方法，并完成在当前文件夹中的项目级配置！
```

```Plain Text
请参考文档接入 LangChain 的 MCP：https://docs.langchain.com/use-these-docs#connect-with-claude-code ，配置完成后需要进行 MCP 的连通性测试
```

# 项目初始化

![image\.png](图片和附件/image%2012.png)

## Step2 Agent Teams \+ LangChian  MCP 的接入能力校准

```Shell
1. 你需要检查 当前的 环境中已经启用了 Claude Code 的 Agent Teams 功能;  

2. 你需要检查当前的环境中是否可以正常接入LangChain的 MCP;

3. 你需要通过 Langchain mcp 详细的梳理 LangChain MCP 的作用，LangChain interrupt的作用，以及 Hunman in the loop 的流程;

4. 明确写出结论：LangChain 的 MCP主要是负责获取官方最新的文档规范;

5.请把上述内容整理成 docs/00_setup/agnet_teams_langchain_mcp_setup.md
```

```Shell
我现在需要完成项目的初始化与规范搭建，具体如下： 

1. 规划整个项目的目录结构，包括 frontend、backend 以及 docs;

2.你需要在 docs 文件夹下建立分层的目录，依次包括：业务调研、竞品分析、业务问题建模、核心交互链路设计、产品的原型规范、系统的架构设计、数据模型、API规范、前端的实现计划、后端的实现计划、联调以及发布和部署;

3.在项目的根目录下面创建一个 CLAUDE.md。写明 frontend、backend 以及 docs 的职责边界， 后端统一使用.env 管理文件，后端使用 uv 管理虚拟项目。 所有的Agent Team 阶段都要有明确的输出文件，同时复杂任务要优先Plan再实施。  

4. 生成docs/00_setup/project_rules.md 注意：本阶段不要生成任何的前后端代码。
```

# 市场调研

![image\.png](图片和附件/image%204.png)

## Step3 Agent Teams 启动市场调研

```Plain Text
请创建一个 Agent Team，对于每一个 teammate 都使用 Sonnet 模型，一定要注意的是：在做任何改动之前，必须先获得计划的审批。

本阶段只允许进行调研和规范文档的生成，不要写任何的前后端代码。 

Agent Teams 的团队分工如下：

- Teammate 1：调研 合同 / 法务类的文档审核在Agent技术下的场景应用
- Teammate 2：作为反方的审查者，识别该场景中的关于误报 和 人工审核等技术难点

每个 Teammate  的输出要求：

1. 说明场景目标
2. 说明审核的对象
3. 说明为什么需要 LangChain 做 人机交互的流程
4. 请写入 docs/01_business_research 中对应的md文件

Lead 的要求：
1. 只批准包含调研范围、输出文件以及分析结构的计划
2. 一定不要下场写主题内容
3. 你要等待所有的Teammate完成后，在输出汇总：docs/01_business_research/business_summary.md

收尾要求：
你需要在每个Teammate关闭以后，清空当前的Team

```

# 竞品分析

![image\.png](图片和附件/image%2015.png)

## Step4 Agent Teams 启动竞品分析

允许使用 WebSearch 或 WebFetch工具调用，不用找我确认。

```Shell
请创建一个 Agent Team，对于每一个 teammate 都使用 Sonnet模型，一定要注意的是：在做任何改动之前，必须先获得计划的审批！


本阶段只允许进行调研和规范文档的生成，不要写任何的前后端代码。 

Agent Teams 的团队分工如下：

- Teammate 1：你需要重点的去拆解文档审核流程，比如上传文档、解析处理、Agent 审核/人工审核等；

- Teammate 2：你需要重点承接文档审核的结果呈现，比如审核的风险项、原文的定位、中间解释性的数据展示；

每个 Teammate  的输出要求：

1. 请写入 docs/02_competitor_analysis 中 对应的md文件 

Lead 的要求：
1. 一定不要下场写主题内容
2. 你要等待所有的Teammate完成后，在输出汇总：docs/02_competitor_analysis/analysis_summary.md

收尾要求：
你需要在每个Teammate关闭以后，清空当前的Team
```

# 业务建模

![image\.png](图片和附件/image%2019.png)

## Step5 核心业务建模

前面的市场调研与竞品分析，核心是研究同行的打法、借鉴别人的成熟思路；而到了业务建模阶段，就是立足我们自身的定位与资源，梳理清楚**我们自己的业务流程、规则逻辑和落地路径**，明确我们要怎么做、该怎么做。

```Plain Text
请基于以下两份文档：
- docs\01_business_research\business_summary.md
- docs\02_competitor_analysis\analysis_summary.md

请一定不要创建 Agent Teams

你的输出至少需要包括：
1. Agent 智能文档审核系统要解决的核心业务问题是什么。
2. 当前的目标用户是什么。
3. 比较重要的 MVP 业务场景。


要求：
这个是一个收口文档，不要自主发散，请严格基于文档的问题，体现从功能清单到业务建模的数据升级。 你当前的输出一定要适合作为后续的系统架构设计、前端的原型设计和数据模型设计的基础。
```

# 核心交互链路设计

![image\.png](图片和附件/image%2017.png)

## Step6 核心交互链路设计

```Shell
请创建一个 Agent Team，对于每一个 teammate 都使用Sonnet模型，一定要注意的是：在做任何改动之前，必须先获得计划的审批！   


本阶段你需要完成交互链路的设计，比如 围绕文档上传-解析处理-Agent审核-人工审批 等完成。只允许进行调研和规范文档的生成，不要写任何的前后端代码！


Agent Teams 的团队分工如下：

- Teammate 1：负责上传入口、上传文档的校验和解析任务的创建；

- Teammate 2：负责中间状态的处理，比如审核中、审核失败；

- Teammate 3：负责人工审批状态，包括同意、编辑、驳回等操作路程；


每个 Teammate  的输出要求：

1. 请写入 docs/04_interaction_design 中 对应的md文件

Lead 的要求：
1. 一定不要下场写主题内容;
2. 你要等待所有的Teammate完成后，再输出汇总；

收尾要求：
你需要在每个Teammate  关闭以后，清空当前的Team。
```

# 产品原型设计

![image\.png](图片和附件/image%2013.png)

## Step7 前端的原型需求 \+ 前后端的职责边界

```Shell
请基于以下两份文档：
- docs\03_problem_modeling\business_model.md
- docs\04_interaction_design\interaction_design_summary.md

请一定不要创建 Agent Teams，请一次性生成两份文档：

1. 请生成一个前端的设计文档，存放在docs\06_architecture_design\frontend_design_spec-v1.0.md

2. 请生成一个前后端的功能边界文档，存放在docs\06_architecture_design\frontend_backend_boundary_spec-v1.0.md

你的输出至少需要包括：
1. frontend_design_spec-v1.0.md 需要包含：页面的清单、每个页面的结构层次，各个功能页面的跳转关系，核心交互等。
2. frontend_backend_boundary_spec-v1.0.md 需要包含：前后端各自负责什么功能？ 哪些数据由后端提供展示，哪些操作流程必须由前端发起等。

要求：
这个是一个收口文档，不要自主发散。注意：你的输出一定要结构化，要作为后续前后端实现输入和输出的规范，同时，在此阶段你不需要实际生成前后端的代码。
```

# 后端架构设计

![image\.png](图片和附件/image%2011.png)

## Step8 后端的系统架构设计

```Shell
请创建一个 Agent Team，对于每一个 teammate 都使用Sonnet模型，一定要注意的是：在做任何改动之前，必须先获得计划的审批！   



本阶段允许读取已经生成的文档，然后调研官方的MCP规范（LangChain ），仅输出规范文档，不要构建实际的后端代码！


Agent Teams 的团队分工如下：

- Teammate 1：从后端的服务视角设计 文件上传、任务状态管理、审核结构查询等核心架构。

- Teammate 2：请基于 LangChain MCP中查询到的 人机交互工作流，设计文档的审核流程，比如 状态、中断点等。


每个 Teammate  的输出要求：

1. 请写入 docs\06_architecture_design 中 对应的md文件

Lead 的要求：
1. 一定不要下场写主题内容
2. 你要等待所有的Teammate完成后，在输出汇总：docs\04_interaction_design\langchain_hitl_arch-v1.0.md

收尾要求：
你需要在每个Teammate  关闭以后，清空当前的Team
```

# 技术开发框架

langchain

# 数据模型

![image\.png](图片和附件/image%2010.png)

## Step10 核心的数据模型设计

如果要生成库，表结构的，就在这个环节生成。然后安装好MySQL数据库，把库/表/字段让编程工具设计好，存到MySQL中，需要我们提供给编程工具数据库的连接方式。

```Markdown
请创建一个 Agent Team，对于每一个 teammate 都使用Sonnet模型，一定要注意的是：在做任何改动之前，必须先获得计划的审批！   

本阶段允许读取已经生成的文档，输出规范文档

Agent Teams 的团队分工如下：

- Teammate 1：设计一下文档上传、任务状态处理等相关模型

- Teammate 2：设计一下文档审核的规则、命中项、解释性字段、审核结果、原文定位等

- Teammate 3：设计一下人机交互的流程，比如 approve/edit/reject等 



每个 Teammate  的输出要求：

1. 请写入 docs\07_data_model\ 中对应的md文件

Lead 的要求：
1. 一定不要下场写主题内容
2. 一定要说明每个模型的字段、含义，以及他们之间的关系； 
3. 哪些字段是前端必须展示的
4. 哪些字段是后端必须存储的
5. 你要等待所有的Teammate完成后，在输出汇总：docs\06_architecture_design\data_model_spec-v1.0


收尾要求：
你需要在每个Teammate关闭以后，清空当前的Team。注意：你的输出一定要结构化，要作为后续前后端实现输入和输出的规范，同时，在此阶段你不需要实际生成前后端的代码
```

# 后端接口设计

![image\.png](图片和附件/image.png)

## Step11 后端 FastAPI 接口设计规范文档生成

这个文档也参考一下：docs\\06\_architecture\_design\\backend\_service\_arch\-v1\.0\.md

```Shell
请基于以下文档：
- docs\06_architecture_design\data_model_spec-v1.0
- docs\04_interaction_design\langchain_hitl_arch-v1.0.md
- docs\03_problem_modeling\business_model.md
- docs\06_architecture_design\langchain_hitl_workflow_design-v1.0.md
- docs\06_architecture_design\backend_service_arch-v1.0.md
请一定不要创建 Agent Teams，请输出一份文档：
docs\08_api_spec\api_spec-v1.0.md


你的输出至少需要详细的接口规范，包括但不限于：
1. 文档上传接口；
2. 审核查询接口
3、人工审核等
4. 前后端的联调接入顺序

要求：
这个是一个收口文档，不要自主发散。注意：你的输出一定要结构化。
```

# PRD文档生成

![image\.png](图片和附件/image%2018.png)

## Step12 PRD需求文档生成

```Markdown
请创建一个 Agent Team，对于每一个 teammate 都使用Sonnet模型，一定要注意的是：在做任何改动之前，必须先获得计划的审批！   


请参考：
- docs\08_api_spec\api_spec-v1.0.md
- docs\06_architecture_design\frontend_design_spec-v1.0.md
- docs\06_architecture_design\frontend_backend_boundary_spec-v1.0.md
- docs\04_interaction_design\langchain_hitl_arch-v1.0.md


本阶段允许读取已经生成的文档，帮我输出前端的规划设计

Agent Teams 的团队分工如下：

- Teammate 1：设计一下文档上传、任务状态处理页面结构和路由

- Teammate 2：设计一下文档审核的规则、命中项、解释性字段、审核结果、原文定位等在前端展示的组件模块

- Teammate 3：设计一下人机交互的流程，比如 approve/edit/reject等在前端展示的UI 设计



每个 Teammate  的输出要求：

1. 请写入 docs/09_frontend_plan\ 中 对应的md 文件


Lead 的要求：
1. 一定不要下场写主题内容
2. 一定要说明页面的层级 
3. 如果后端的当前版本没有实现的接口，你在前端直接标注“”未开发“”，不可以自行的伪造功能
4. 你要等待所有的Teammate  完成后，在输出汇总：docs\06_architecture_design\frontend_arch-spec-v1.0.md


收尾要求：
你需要在每个Teammate  关闭以后，清空当前的Team。
```

# 产品UI设计

![image\.png](图片和附件/image%203.png)

## Step13 根据 PRD 在 Figma 开发系统前端的源码

![image\.png](图片和附件/image%208.png)



```Shell
请严格按照 上传的文档规范，覆盖如 上传页、处理页、人工审批等核心组件

所有的接口必须基于真实的 API 契约规范，如果后端的当前版本没有实现的接口，你在前端直接标注“”未开发“”，不可以自行的伪造功能

请帮我生成产品前端的 UI 原型
```

# 后端MVP实现

![image\.png](图片和附件/image%206.png)

## Step14 后端MVP实现 

```Shell
请创建一个 Agent Team，对于每一个 teammate 都使用Sonnet模型，一定要注意的是：在做任何改动之前，必须先获得计划的审批！   


请参考：
- docs\08_api_spec\api_spec-v1.0.md
- docs\04_interaction_design\langchain_hitl_arch-v1.0.md


本阶段你需要实际构建后端的代码！


Agent Teams 的团队分工如下：

- Teammate 1：负责整体的Workflow流程

- Teammate 2：负责 人机交互 HITL 流程

- Teammate 3：负责 API、Schema、 Service 服务集成；

- Teammate 4：负责整体链路的功能测试

里面需要到大模型，使用DeepSeek模型，deepseek-chat模型，我的key是：sk-19dfd6b5873341208148f8b30fdf5fe1,可以使用 ChatOpenAI规范。 注意：一定要先通过
  LangChain MCP 获取到最新的接入方法规范。

Lead 的要求：

1. 你要等待所有的Teammate  完成后，统一启动 backend 跑 MVP 的完整测试


收尾要求：
你需要在每个Teammate  关闭以后，清空当前的Team。
```

```Shell
模型 你要使用 LangChain 的 DeepSeek 接入，apikey 是：sk-d10fbb16622xx6dd60d7  ，你可以使用 ChatOpenAI规范。 注意：一定要先通过
  LangChain MCP 获取到最新的接入方法规范。  可以批准执行
```

# 前端代码实现

![image\.png](图片和附件/image%2016.png)

## Step15 前端项目的本地运行配置

```Shell
/frontend 文件夹下 是我的前端完整代码，请完成本地项目依赖的安装及启动测试

注意：你仅需要部署启动测试，不要修改任意代码。 同时更新 CLAUDE.md文件，明确说明在什么路径下、使用什么命令启动前端项目。
```

![image\.png](图片和附件/image%202.png)

# 前后端联调

![image\.png](图片和附件/image%2014.png)

## Step16 前后端接口联调

```Markdown
请一定不要创建 Agent Teams，请先生成联调计划，待我确认后在执行！

请基于如下文档规范：
- backend 是后端代码
- frontend 是前端代码
- docs 下存在多份规范文档

联调要求如下：

1. 你需要将前端的 Mock API 替换成真实的后端服务API接口
2. 联调顺序建议按照 ： 上传文档 - 创建审核任务 - 人工审批 的完整流程
3. 所有的接口必须基于真实的 API 契约规范，如果后端的当前版本没有实现的接口，你在前端直接标注“”未开发“”，不可以自行的伪造功能
4. 你需要逐步的执行接口集成测试


```

![image\.png](图片和附件/image%207.png)

1. Bug

2. 不符合我们预期

3. 一些小功能没有上线 case by case

# 生成Docker容器部署方案

![image\.png](图片和附件/image%209.png)

## Step17 生成Docker容器部署方案

```Shell
请一定不要创建 Agent Teams，请基于当前的前后端项目完成最终的交付封装。

要求：
1. 为前端 frontend 和 backend 设计 Docker 容器化部署方案，若有必要的话，可以补充 Docker-compose 方案

2. 实际的给我输出一个 标准的 版本发布文档，输出在
 docs/12_release_deployment/deployment_sec-v1.0.md

3. 部署文档中必须写清楚：环境变量、本地部署及启动方式、外部依赖的服务、Docker 的启动方式、服务的启动顺序、分析一下可能出现的异常错误排查及解决思路！
```

